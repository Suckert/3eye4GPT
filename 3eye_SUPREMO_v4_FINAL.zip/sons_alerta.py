# Simulação: Sons ativados para eventos críticos
