# Simulação: Reexibição dos eventos com explicações da IA
