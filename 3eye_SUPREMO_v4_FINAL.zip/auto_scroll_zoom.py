# Simulação: Código que move a tela automaticamente com base no OCR
