# Simulação: Tooltips com explicações de candles e padrões
