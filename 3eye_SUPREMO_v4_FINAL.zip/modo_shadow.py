# Simulação: Modo passivo onde IA só observa e registra
