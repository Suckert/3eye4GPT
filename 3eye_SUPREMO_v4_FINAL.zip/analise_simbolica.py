# Simulação: IA detecta padrões simbólicos e zonas de armadilha
