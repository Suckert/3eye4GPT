# Simulação: Multiprocessing para execução paralela de sinais
