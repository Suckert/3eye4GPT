# Script de configuração automática da API da Binance
