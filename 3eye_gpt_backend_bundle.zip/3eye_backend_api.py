from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import ccxt
import os
from dotenv import load_dotenv

load_dotenv()

app = FastAPI()

binance = ccxt.binance({
    'apiKey': os.getenv("API_KEY_BINANCE"),
    'secret': os.getenv("SECRET_KEY_BINANCE")
})

class Ordem(BaseModel):
    par: str
    acao: str
    quantidade: float

class ScoreRequest(BaseModel):
    par: str

class Log(BaseModel):
    par: str
    acao: str
    preco: float
    score: float
    resultado: str

@app.post("/executar_ordem")
def executar_ordem(data: Ordem):
    try:
        if data.acao not in ["buy", "sell"]:
            raise HTTPException(status_code=400, detail="Ação inválida")
        preco = binance.fetch_ticker(data.par)['last']
        ordem = getattr(binance, f"create_market_{data.acao}_order")(data.par, data.quantidade)
        return {"status": "ok", "preco": preco, "ordem_id": ordem['id']}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/saldo")
def saldo():
    try:
        return binance.fetch_balance()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/obter_score")
def obter_score(data: ScoreRequest):
    return {"score": 0.85, "sentimento": "Positiva"}

@app.post("/salvar_log")
def salvar_log(data: Log):
    with open("logs_trading.csv", "a") as f:
        f.write(f"{data.par},{data.acao},{data.preco},{data.score},{data.resultado}\n")
    return {"status": "log salvo"}
