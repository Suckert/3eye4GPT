import pandas as pd
import os

def salvar_historico_operacoes(df, path="historico_operacoes.csv"):
    df.to_csv(path, index=False)

def carregar_historico_operacoes(path="historico_operacoes.csv"):
    if os.path.exists(path):
        return pd.read_csv(path, parse_dates=["DataHora"])
    return pd.DataFrame(columns=["DataHora", "Ativo", "Ação", "Lucro", "Saldo"])
