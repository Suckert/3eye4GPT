from indicators import indicator_score

profile_info = {
    "Conservador": "Opera sinais seguros via RSI baixo (<30) ou RSI alto (>70). Risco mínimo, crescimento lento.",
    "Agressivo": "Compra com fortes tendências (MACD > signal), risco alto.",
    "Multiplicação Divina": "Opera consenso de vários sinais (score alto), proteção dinâmica.",
    "Harmônico": "Opera reversões rápidas, padrões de candle.",
}

class Conservador:
    @staticmethod
    def signal(df):
        rsi = indicator_score(df)["rsi"]
        if rsi < 30: return "Buy"
        if rsi > 70: return "Sell"
        return "Hold"

class Agressivo:
    @staticmethod
    def signal(df):
        ind = indicator_score(df)
        if ind["macd"] > ind["signal"]: return "Buy"
        elif ind["macd"] < ind["signal"]: return "Sell"
        return "Hold"

class MultiplicacaoDivina:
    @staticmethod
    def signal(df):
        ind = indicator_score(df)
        if ind["score"] >= 3 and ind["probabilidade_alta"] > 65: return "Buy"
        elif ind["score"] <= -3 and ind["probabilidade_alta"] < 35: return "Sell"
        return "Hold"

class Harmonico:
    @staticmethod
    def signal(df):
        # Exemplo: Use score + reversão de tendência
        ind = indicator_score(df)
        if ind["score"] > 1 and ind["tendencia"] == "Alta": return "Buy"
        elif ind["score"] < -1 and ind["tendencia"] == "Baixa": return "Sell"
        return "Hold"

STRATS = {
    "Conservador": Conservador,
    "Agressivo": Agressivo,
    "Multiplicação Divina": MultiplicacaoDivina,
    "Harmônico": Harmonico
}

def multi_perfil_signal(exchange, ativos, perfis, modo_op, pesos=(50,50), quant_padrao=0.01):
    # Suporta 1 ou 2 perfis em combinação
    for ativo in ativos:
        df = exchange.fetch_ohlcv_df(ativo, timeframe='1h', limit=100)
        sinais = []
        for idx, perfil in enumerate(perfis if isinstance(perfis, list) else [perfis]):
            for _ in range(int(pesos[idx] if pesos else 100)):
                sinais.append(STRATS[perfil].signal(df))
        buy_count = sinais.count("Buy")
        sell_count = sinais.count("Sell")
        final = "Buy" if buy_count > sell_count else "Sell" if sell_count > buy_count else "Hold"
        if final == "Buy":
            if modo_op == "Real":
                exchange.create_market_order(ativo, "buy", quantidade=quant_padrao)
            # log_event(ativo, "buy", datetime.now()) # Ative se desejar log
        elif final == "Sell":
            if modo_op == "Real":
                exchange.create_market_order(ativo, "sell", quantidade=quant_padrao)
            # log_event(ativo, "sell", datetime.now())
