import streamlit as st
import pandas as pd
import numpy as np
import os
import openai
from dotenv import set_key, load_dotenv
import requests
from datetime import datetime
import random

# ------------------- CONFIGURAÇÃO INICIAL ----------------------
st.set_page_config(page_title="3eye IA Ultimate", layout="wide")
load_dotenv(".env")

# -------------- FUNÇÕES ÚTEIS E INDICADORES ---------------
def salvar_historico_operacoes(df):
    historico_path = "historico_operacoes.csv"
    if os.path.exists(historico_path):
        df_antigo = pd.read_csv(historico_path)
        df = pd.concat([df_antigo, df], ignore_index=True)
    df.to_csv(historico_path, index=False)

def carregar_historico_operacoes():
    historico_path = "historico_operacoes.csv"
    if os.path.exists(historico_path):
        return pd.read_csv(historico_path)
    return pd.DataFrame(columns=["Ativo", "Ação", "Preço", "Quantidade", "DataHora"])

def reset_history():
    if os.path.exists("historico_operacoes.csv"):
        os.remove("historico_operacoes.csv")

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def compute_sharpe(returns, rf=0):
    mean_ret = returns.mean()
    std_ret = returns.std()
    return (mean_ret - rf) / std_ret if std_ret > 0 else 0

def compute_sortino(returns, rf=0):
    mean_ret = returns.mean()
    neg_std = returns[returns < 0].std()
    return (mean_ret - rf) / neg_std if neg_std > 0 else 0

def compute_drawdown(capital_curve):
    roll_max = capital_curve.cummax()
    drawdown = capital_curve / roll_max - 1
    return drawdown.min(), drawdown

def compute_volatility(series):
    return series.pct_change().std() * np.sqrt(252)

# --------- ESTRATÉGIAS / MULTI-STRATEGY / HYBRID ------------
class BaseStrat:
    def signal(self, df):
        rsi = compute_rsi(df['close']).iloc[-1]
        if rsi < 30:
            return "buy"
        elif rsi > 70:
            return "sell"
        else:
            return "hold"

class AggressiveStrat:
    def signal(self, df):
        if df['close'].iloc[-1] > df['close'].mean():
            return "buy"
        else:
            return "sell"

class IA_PowerStrat:
    def signal(self, df):
        # Simula IA: 10% de chance de hold, 45% buy, 45% sell
        rnd = random.random()
        if rnd < 0.45:
            return "buy"
        elif rnd < 0.9:
            return "sell"
        else:
            return "hold"

profile_info = {
    "Multiplicação Divina": "Cruza sinais, proteção dinâmica, máxima multiplicação.",
    "Conservador": "Opera sinais seguros, proteção máxima.",
    "Agressivo": "Busca oportunidades rápidas, maior risco.",
    "Balanceado": "Equilíbrio entre risco e segurança.",
    "IA Power": "Usa máximo poder de IA (simulado).",
    "Híbrido (Agressivo+IA Power)": "Combina sinais de Agressivo e IA Power."
}
STRATS = {
    "Multiplicação Divina": BaseStrat(),
    "Conservador": BaseStrat(),
    "Agressivo": AggressiveStrat(),
    "Balanceado": BaseStrat(),
    "IA Power": IA_PowerStrat(),
    "Híbrido (Agressivo+IA Power)": None  # Montado no código
}

# ------------- OLHO DE SALOMÃO (IA/MANUAL) -----------------
def obter_top_ativos_salomao(ativos_analise, n=6, ia_ativa=False, openai_api_key=None):
    # Simule análise avançada, aqui entraria IA real + scraping + indicadores!
    scores = {a: round(random.uniform(7,10), 2) for a in ativos_analise}
    racional = "Sinais cruzados (IA, indicadores, notícias, volatilidade e risco global)."
    return scores, racional

def exibir_racional_ia(racional):
    st.markdown(f"> **Justificativa:** {racional}")

# ----------- ANALISE DE NOTICIAS E SENTIMENTO ---------------
def analisar_noticias_sentimento(ativo):
    # Simulação - substitua por scraping/news API
    sentimento = random.choice(["Muito positivo", "Positivo", "Neutro", "Negativo", "Muito negativo"])
    score = {"Muito positivo": 2, "Positivo": 1, "Neutro": 0, "Negativo": -1, "Muito negativo": -2}[sentimento]
    return sentimento, score

# --------------- STOP DE EMERGÊNCIA GLOBAL ------------------
def stop_emergencia_drawdown(capital_curve, limite_dd=-0.15):
    dd_min, dd_curve = compute_drawdown(capital_curve)
    if dd_min <= limite_dd:
        return True, dd_min
    return False, dd_min

# ----------------- SIMULAÇÃO INTELIGENTE --------------------
def simular_risco_volatilidade(df):
    returns = df['close'].pct_change().dropna()
    sharpe = compute_sharpe(returns)
    sortino = compute_sortino(returns)
    vol = compute_volatility(df['close'])
    dd, _ = compute_drawdown(df['close'].cumsum())
    return {"Sharpe": sharpe, "Sortino": sortino, "Vol": vol, "Drawdown": dd}

# --------------- SIDEBAR & CONFIG ---------------------------
logo_path = "Logo.png"
if os.path.exists(logo_path):
    st.markdown(
        f"""<div style="position: absolute; top: 18px; left: 18px; z-index: 99;">
            <img src="file://{os.path.abspath(logo_path)}" width="56" style="margin-bottom:10px;" />
        </div>""", unsafe_allow_html=True
    )

THEMES = {
    "Apple Clean": "",
    "Apple Dark": "",
    "Neon Cyberpunk": "",
    "Bloomberg Pro": "",
    "Crystal Matrix": ""
}
st.sidebar.header("👁️ Tema Visual")
theme = st.sidebar.selectbox("", list(THEMES.keys()), index=0)
if THEMES[theme]:
    st.markdown(THEMES[theme], unsafe_allow_html=True)

st.sidebar.header("⚙️ Configuração Completa")
api_key_binance = st.sidebar.text_input("Binance API Key", type="password", value=os.getenv("API_KEY_BINANCE", ""))
secret_key_binance = st.sidebar.text_input("Binance Secret Key", type="password", value=os.getenv("SECRET_KEY_BINANCE", ""))
openai_api_key = st.sidebar.text_input("OpenAI API Key", type="password", value=os.getenv("OPENAI_API_KEY", ""))

if st.sidebar.button("💾 Salvar Configurações"):
    set_key(".env", "API_KEY_BINANCE", api_key_binance)
    set_key(".env", "SECRET_KEY_BINANCE", secret_key_binance)
    set_key(".env", "OPENAI_API_KEY", openai_api_key)
    openai.api_key = openai_api_key
    st.sidebar.success("Configurações salvas! Recarregue o app.")

openai.api_key = openai_api_key

def consultar_saldo_openai(api_key):
    url = "https://api.openai.com/dashboard/billing/credit_grants"
    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        r = requests.get(url, headers=headers, timeout=15)
        if r.status_code == 200:
            saldo = r.json().get("total_available", 0.0)
            return saldo
        return None
    except Exception: return None

saldo_openai = consultar_saldo_openai(openai_api_key)
if saldo_openai and saldo_openai > 0: st.sidebar.success(f"OpenAI OK: ${saldo_openai:.2f}")
else: st.sidebar.warning("API OpenAI sem saldo ou não conectada.")

# Dummy exchange para simulação local (troque por integração real quando quiser)
class DummyExchange:
    def fetch_ohlcv(self, ativo, timeframe='1h', limit=100):
        base = 50000 if 'BTC' in ativo else 1000
        price = np.abs(base + np.random.randn(limit).cumsum())
        return [[datetime.now().timestamp()*1000 + i*3600000, p, p+50, p-50, p, random.randint(1, 10)] for i,p in enumerate(price)]

exchange = DummyExchange()

ia_ativa = st.sidebar.toggle("🔮 Ativar IA (Olho de Salomão)", value=(saldo_openai and saldo_openai > 0))
exec_ativo = st.sidebar.toggle("⚡ Executor Automático IA", value=False)
st.sidebar.markdown(f"Status Executor: {'🟢 ATIVO' if exec_ativo else '🔴 DESLIGADO'}")

perfil = st.sidebar.selectbox("👤 Perfil de Trading", list(STRATS.keys()))
modo_op = st.sidebar.radio("🚀 Modo de Execução", ["Simulação", "Real"])
trade_base = st.sidebar.selectbox("Base das Operações", ["BTC/USDT", "USDT", "Todos Ativos"])
ativos_analise = [
    "BTC/USDT","ETH/USDT","BNB/USDT","SOL/USDT","XRP/USDT","ADA/USDT","DOGE/USDT","AVAX/USDT",
    "DOT/USDT","LINK/USDT","TRX/USDT","LTC/USDT","MATIC/USDT","UNI/USDT","ATOM/USDT",
    "OP/USDT","SUI/USDT","INJ/USDT","RNDR/USDT","ARB/USDT","FIL/USDT","PEPE/USDT","BLUR/USDT",
    "SEI/USDT","TIA/USDT","SHIB/USDT","JUP/USDT","PYTH/USDT","APT/USDT",
    "FET/USDT","GMT/USDT","GMX/USDT"
]
ativos_escolhidos = st.sidebar.multiselect(
    "Selecione até 10 ativos", ativos_analise, default=ativos_analise[:6], max_selections=10
)
intervalo_refresh = st.sidebar.slider("⏱ Intervalo (s)", 10, 120, 20)
n_top = st.sidebar.slider("N° de moedas IA", 3, 10, 6)

with st.sidebar.expander("📋 Resumo Configuração"):
    st.write(f"Perfil: {perfil}")
    st.write(f"Modo: {modo_op}")
    st.write(f"IA: {'Ativa' if ia_ativa else 'Desativada'}")
    st.write(f"Executor: {'Automático' if exec_ativo else 'Manual'}")
    st.write(f"Trade Base: {trade_base}")
    st.write(f"Intervalo: {intervalo_refresh}s")
    st.write(f"Ativos: {', '.join(ativos_escolhidos)}")
    st.write(f"Tema: {theme}")

tabs = st.tabs([
    "Dashboard", "Olho de Salomão", "Carteira", "Execução", "Motor de Vidro", "Histórico", "3eye Vision", "Manual", "Backtest", "Status"
])

# ------------------- DASHBOARD ----------------------
with tabs[0]:
    st.title("👁️ 3eye Ultimate – Painel Geral (Landing Page)")
    df_hist = carregar_historico_operacoes()
    capital_inicial = 10000
    # --------- Performance e Stop Emergencial -----------
    if not df_hist.empty:
        df_hist = df_hist.sort_values("DataHora")
        df_hist["Valor"] = df_hist["Preço"] * df_hist.get("Quantidade", 1)
        df_hist["Capital"] = capital_inicial + df_hist["Valor"].cumsum()
        lucro_total = df_hist["Valor"].sum()
        n_trades = len(df_hist)
        acertos = len(df_hist[df_hist["Ação"].str.lower() == "buy"])
        st.subheader("📈 Performance e Estatísticas")
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Capital Atual", f"${df_hist['Capital'].iloc[-1]:,.2f}")
        col2.metric("Lucro Total", f"${lucro_total:,.2f}")
        col3.metric("Nº Trades", f"{n_trades}")
        col4.metric("Acertos", f"{acertos}")
        st.line_chart(df_hist[["Capital"]])
        # Stop de emergência
        stop_now, dd_val = stop_emergencia_drawdown(df_hist['Capital'])
        if stop_now:
            st.error(f"⚠️ STOP DE EMERGÊNCIA ATIVADO! Drawdown atual: {100*dd_val:.1f}%")
        else:
            st.info(f"Drawdown global atual: {100*dd_val:.2f}%")
    else:
        st.info("Nenhuma operação registrada ainda.")
    st.markdown("---")
    # ------------- Carteira & Ranks Avançados --------------
    st.subheader("💼 Carteira Atual (Espelho Resumido)")
    if exchange:
        saldo_sim = {
            ativo: {"saldo": round(100 + (i*5), 2), "preco_atual": 20+2*i, "lucro": round((i-3)*13,2)}
            for i, ativo in enumerate(ativos_escolhidos)
        }
        df_cart = pd.DataFrame([
            [a, v["saldo"], v["preco_atual"], v["saldo"]*v["preco_atual"], v["lucro"]]
            for i, (a, v) in enumerate(saldo_sim.items())
        ], columns=["Ativo", "Saldo", "Preço Atual", "Valor Total", "Lucro"])
        df_cart["% Alocação"] = df_cart["Valor Total"]/df_cart["Valor Total"].sum()*100
        # Calcule rank Sharpe/Sortino/Vol
        df_cart["Sharpe"] = np.nan
        df_cart["Sortino"] = np.nan
        df_cart["Vol"] = np.nan
        for i, ativo in enumerate(ativos_escolhidos):
            fake_prices = np.abs(np.random.randn(100).cumsum() + 100)
            fake_df = pd.DataFrame({"close": fake_prices})
            ret = fake_df['close'].pct_change().dropna()
            df_cart.loc[df_cart['Ativo']==ativo, "Sharpe"] = compute_sharpe(ret)
            df_cart.loc[df_cart['Ativo']==ativo, "Sortino"] = compute_sortino(ret)
            df_cart.loc[df_cart['Ativo']==ativo, "Vol"] = compute_volatility(fake_df['close'])
        st.dataframe(df_cart)
        st.metric("Lucro Total", f"${df_cart['Lucro'].sum():,.2f}")
        st.bar_chart(df_cart.set_index("Ativo")["Valor Total"])
        st.markdown("#### 🔝 RANKING (Mais seguro > arriscado):")
        st.dataframe(df_cart.sort_values(["Sharpe", "Sortino", "Vol"], ascending=[False,False,True]))
    else:
        st.warning("Conecte sua conta Binance para ver a carteira real.")

    st.markdown("---")
    st.subheader(f"🔮 Top {n_top} Moedas Recomendadas Hoje (Olho de Salomão)")
    try:
        scores, racional = obter_top_ativos_salomao(ativos_escolhidos, n_top, ia_ativa)
        df_ia = pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota IA"]).sort_values("Nota IA", ascending=False)
        topN = df_ia.head(n_top)["Ativo"].tolist()
        st.info(f"Top{n_top}: {', '.join(topN)}")
        st.dataframe(df_ia)
        exibir_racional_ia(racional)
    except Exception as e:
        st.error(f"Erro na IA: {e}")
    st.markdown("---")
    st.subheader("📜 Últimas Operações")
    if not df_hist.empty:
        st.dataframe(df_hist.tail(10))
    else:
        st.info("Nenhuma operação registrada ainda.")
    st.markdown("---")
    st.subheader("🛡️ Status & Segurança do Sistema")
    now = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
    def status_icon(ok): return "✅" if ok else "❌"
    status_data = [
        ("Conexão Binance", status_icon(exchange is not None), 
         "Conectado" if exchange else "Verifique API/Secret e conexão Internet"),
        ("IA Ativa", status_icon(ia_ativa), "IA funcionando" if ia_ativa else "IA desligada ou sem saldo"),
        ("Horário Atual", "🕒", now),
        ("Ativos escolhidos", status_icon(len(ativos_escolhidos) > 0), f"{', '.join(ativos_escolhidos)}"),
    ]
    st.table(pd.DataFrame(status_data, columns=["Recurso", "Status", "Motivo/Descrição"]))
    st.markdown("---")
    st.subheader("💡 Dicas & Alertas Inteligentes")
    st.info("Proteja sempre seu capital! Use stop-loss, take-profit, revise o Motor de Vidro para evitar perdas desnecessárias.")
    st.success("Painel pronto para rodar com stop de emergência, ranks de risco e simulação inteligente.")

# ------- RESTANTE DAS ABAS (Estrutura exemplo, expanda conforme necessário) ---------

with tabs[1]:
    st.header("🔮 Olho de Salomão")
    scores, racional = obter_top_ativos_salomao(ativos_escolhidos, n_top, ia_ativa)
    df_ia = pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota IA"]).sort_values("Nota IA", ascending=False)
    st.dataframe(df_ia.head(n_top))
    exibir_racional_ia(racional)
    st.markdown("#### Notícias e Sentimento por Ativo:")
    for ativo in ativos_escolhidos:
        sentimento, score = analisar_noticias_sentimento(ativo)
        st.write(f"{ativo}: {sentimento} (score: {score})")
    st.info("Esses dados podem ser integrados via API/scraping para análise real.")

with tabs[2]:
    st.header("💼 Carteira Completa")
    # Exemplo igual ao dashboard

with tabs[3]:
    st.header("⚡ Execução")
    st.write("Execução manual e automática disponível. Configure suas estratégias e perfis no painel lateral.")

with tabs[4]:
    st.header("🛠️ Motor de Vidro")
    st.info("Aqui são exibidos logs e ações do sistema em tempo real.")

with tabs[5]:
    st.header("📜 Histórico")
    df_hist = carregar_historico_operacoes()
    st.dataframe(df_hist)

with tabs[6]:
    st.header("🦾 3eye Vision")
    st.info("Painel de visão total, integração de sinais, IA, logs e análise ao vivo.")

with tabs[7]:
    st.header("📖 Manual & Glossário")
    st.write("Manual detalhado de uso do 3eye IA.")

with tabs[8]:
    st.header("🔬 Backtest Inteligente")
    st.info("Toda vez que trocar o perfil, rode simulação automática aqui!")
    # Simulação automática:
    for ativo in ativos_escolhidos:
        fake_prices = np.abs(np.random.randn(100).cumsum() + 100)
        df_sim = pd.DataFrame({"close": fake_prices})
        sim = simular_risco_volatilidade(df_sim)
        st.write(f"{ativo} - Sharpe: {sim['Sharpe']:.2f}, Sortino: {sim['Sortino']:.2f}, Vol: {sim['Vol']:.2f}, Drawdown: {100*sim['Drawdown']:.2f}%")

with tabs[9]:
    st.header("🔄 Status")
    st.write("Diagnóstico completo do sistema. Veja status de conexões, IA, executor, segurança e performance.")

