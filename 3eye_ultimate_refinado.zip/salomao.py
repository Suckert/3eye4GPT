import streamlit as st
import pandas as pd
import random
from datetime import datetime

# =================== IA/Score Olho de Salomão ===================

def obter_top_ativos_salomao(ativos_analise, n=6, ia_ativa=False, openai_api_key=None):
    """
    Retorna um ranking de ativos com scores baseados em IA (ou randomizado para simulação/offline)
    """
    # Exemplo com IA (adapte para chamada real OpenAI se desejar)
    if ia_ativa and openai_api_key:
        # Simula resposta IA — personalize para uso real da OpenAI!
        scores = {a: round(random.uniform(7, 10), 2) for a in ativos_analise}
        criterios = "Sinais cruzados por IA: momentum, volume, sentimento e notícias globais. Todos os dados analisados em tempo real."
        explicacao = f"Sugestão feita às {datetime.now().strftime('%H:%M')} com base nos 33 ativos, cruzando mais de 30 indicadores e dados globais."
    else:
        scores = {a: round(random.uniform(6, 9), 2) for a in ativos_analise}
        criterios = "Sinais técnicos: RSI, MACD, Volume, Médias Móveis, tendência histórica e volatilidade."
        explicacao = f"Ranking por análise técnica clássica (sem IA). Simula consenso dos principais indicadores técnicos."

    # Organiza por score
    df_ia = pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota"]).sort_values("Nota", ascending=False)
    top_df = df_ia.head(n)
    top_ativos = list(top_df["Ativo"])
    racional = f"""
    - **Critérios:** {criterios}
    - **Explicação:** {explicacao}
    - **Ativos Top:** {', '.join(top_ativos)}
    """

    return dict(zip(top_df["Ativo"], top_df["Nota"])), racional

def exibir_racional_ia(racional):
    st.markdown(f"""
    <div style="background: #202c37; border-radius: 8px; padding: 12px; color: #fff;">
    {racional}
    </div>
    """, unsafe_allow_html=True)

def olho_salomao_tab(exchange, ativos_analise, n_top=6, ia_ativa=False, openai_api_key=None):
    st.header("🔮 Olho de Salomão – Top Moedas & Links")
    scores, racional = obter_top_ativos_salomao(ativos_analise, n_top, ia_ativa, openai_api_key)
    df_ia = pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota"]).sort_values("Nota", ascending=False)
    st.dataframe(df_ia.head(n_top), use_container_width=True)
    exibir_racional_ia(racional)
    if not ia_ativa:
        st.subheader("🌎 Portais de Análise Global:")
        st.markdown("""
- [TradingView](https://www.tradingview.com/)
- [Cointelegraph](https://cointelegraph.com/)
- [Glassnode](https://glassnode.com/)
- [CryptoQuant](https://cryptoquant.com/)
- [Whale Alert](https://whale-alert.io/)
- [Investing.com](https://br.investing.com/crypto/)
        """)
    st.caption("A seleção dos ativos é feita com base nos critérios técnicos e pode ser personalizada no futuro para integração direta com IA e fontes de dados externas.")

# (Opcional) — Scraping de notícias para análise de sentimento global
def news_scraper():
    # Exemplo: substitua por scraping real com requests/BeautifulSoup/fake_useragent
    return [
        "Binance lança nova funcionalidade de futuros.",
        "BTC sobe após decisão do FOMC.",
        "Regulação cripto avança na Europa.",
        "Grandes transações detectadas no Whale Alert."
    ]
