# === APP BASE PRINCIPAL ===
import streamlit as st
from streamlit_autorefresh import st_autorefresh
import pandas as pd
import numpy as np
import ccxt
from ccxt.base.errors import AuthenticationError, DDoSProtection
import os
import webbrowser
from datetime import datetime
from dotenv import load_dotenv, set_key
from textblob import TextBlob
import openai
import plotly.graph_objects as go
import inspect

# Load environment
load_dotenv()
st.set_page_config(page_title="3eye IA Ultra Vision", layout="wide")

# ----------------- INDICATOR FUNCTIONS -----------------
def compute_rsi(series, period=14):
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -delta.clip(upper=0)
    ma_up = up.rolling(period).mean()
    ma_down = down.rolling(period).mean()
    rs = ma_up / ma_down
    return 100 - (100 / (1 + rs))

def compute_atr(df, period=14):
    tr1 = df['high'] - df['low']
    tr2 = (df['high'] - df['close'].shift()).abs()
    tr3 = (df['low'] - df['close'].shift()).abs()
    tr = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
    return tr.rolling(period).mean()

def compute_macd(series):
    ema12 = series.ewm(span=12, adjust=False).mean()
    ema26 = series.ewm(span=26, adjust=False).mean()
    macd = ema12 - ema26
    signal = macd.ewm(span=9, adjust=False).mean()
    return macd, signal

def compute_bollinger(series, period=20):
    ma = series.rolling(period).mean()
    std = series.rolling(period).std()
    return ma + 2*std, ma - 2*std

def compute_obv(df):
    obv = [0]
    for i in range(1, len(df)):
        if df['close'].iloc[i] > df['close'].iloc[i-1]:
            obv.append(obv[-1] + df['vol'].iloc[i])
        elif df['close'].iloc[i] < df['close'].iloc[i-1]:
            obv.append(obv[-1] - df['vol'].iloc[i])
        else:
            obv.append(obv[-1])
    return pd.Series(obv, index=df.index)

def compute_stochastic(df, k_period=14, d_period=3):
    low_min = df['low'].rolling(k_period).min()
    high_max = df['high'].rolling(k_period).max()
    k = 100 * ((df['close'] - low_min) / (high_max - low_min))
    d = k.rolling(d_period).mean()
    return k, d

def compute_vwap(df):
    tp = (df['high'] + df['low'] + df['close']) / 3
    return (tp * df['vol']).cumsum() / df['vol'].cumsum()

def compute_ichimoku(df):
    high9 = df['high'].rolling(9).max()
    low9 = df['low'].rolling(9).min()
    tenkan = (high9 + low9) / 2
    high26 = df['high'].rolling(26).max()
    low26 = df['low'].rolling(26).min()
    kijun = (high26 + low26) / 2
    senkou = ((tenkan + kijun) / 2).shift(26)
    return tenkan, kijun, senkou

def compute_supertrend(df, period=10, multiplier=3):
    atr = compute_atr(df, period)
    hl2 = (df['high'] + df['low']) / 2
    upper = hl2 + multiplier * atr
    lower = hl2 - multiplier * atr
    return upper, lower

# ----------------- OLHO DE SALOMÃO (Sentimento Interno) -----------------
def solen_sentiment(pair, exchange):
    try:
        df = pd.DataFrame(exchange.fetch_ohlcv(pair,'1h',limit=24),
                          columns=['ts','open','high','low','close','vol'])
        mom = df['close'].pct_change().iloc[-1]
        avg_vol = df['vol'][:-1].mean()
        spike = df['vol'].iloc[-1] > 1.5 * avg_vol
        if mom > 0 and spike: return "Positiva"
        if mom < 0 and spike: return "Negativa"
        return "Neutra"
    except Exception:
        return "Indefinido"

# ----------------- STRATEGY CLASSES -----------------
class BaseStrat:
    def signal(self, df, pair=None, sentiment=None):
        return "hold"

class Conservador(BaseStrat):
    def signal(self, df, **kwargs):
        return "buy" if compute_rsi(df['close']).iloc[-1] < 30 else "hold"

class Balanceado(BaseStrat):
    def signal(self, df, **kwargs):
        ma20 = df['close'].rolling(20).mean().iloc[-1]
        ma50 = df['close'].rolling(50).mean().iloc[-1]
        if ma20 > ma50: return "buy"
        if ma20 < ma50: return "sell"
        return "hold"

class Agressivo(BaseStrat):
    def signal(self, df, **kwargs):
        mom = df['close'].pct_change(5).iloc[-1]
        if mom > 0.02: return "buy"
        if mom < -0.02: return "sell"
        return "hold"

class MultiplicacaoDivina(BaseStrat):
    def signal(self, df, pair=None, sentiment=None):
        base = Balanceado().signal(df)
        atr = compute_atr(df).iloc[-1]
        entry = st.session_state.get('entry_prices', {}).get(pair)
        if entry and df['close'].iloc[-1] < entry - 2 * atr:
            return "sell"
        if sentiment == "Positiva" and base == "buy":
            return "buy"
        if sentiment == "Negativa" and base == "sell":
            return "sell"
        return base

class Harmonico(BaseStrat):
    def signal(self, df, **kwargs):
        macd = df['close'].ewm(span=12).mean() - df['close'].ewm(span=26).mean()
        return "buy" if macd.iloc[-1] > 0 else "sell"

class DevocaoFluida(BaseStrat):
    def signal(self, df, **kwargs):
        return "buy" if compute_rsi(df['close']).iloc[-1] < 50 else "sell"

class Profetico(BaseStrat):
    def signal(self, df, **kwargs):
        change = df['close'].pct_change().iloc[-1]
        return "buy" if change > 0 else "sell"

class IAPower(BaseStrat):
    def signal(self, df, pair=None, sentiment=None):
        signals = [
            Conservador().signal(df),
            Balanceado().signal(df),
            Agressivo().signal(df)
        ]
        if sentiment == "Positiva": signals.append("buy")
        return max(signals, key=lambda x: {"sell":0,"hold":1,"buy":2}[x])

STRATS = {
    "Conservador": Conservador(),
    "Balanceado": Balanceado(),
    "Agressivo": Agressivo(),
    "Multiplicação Divina": MultiplicacaoDivina(),
    "Harmônico": Harmonico(),
    "Devoção Fluida": DevocaoFluida(),
    "Profético (3eye e-King)": Profetico(),
    "3eye IA Power": IAPower()
}

# -------------- THEMES --------------
THEMES = {
    "Original": "",
    "Glassmorphism": """
        <style>
        body { background: rgba(18,18,18,0.7); backdrop-filter: blur(10px); color: #ECECEC; }
        .stButton>button { background: rgba(0,229,255,0.8); }
        </style>
    """,
    "Light Apple": """
        <style>
        body { background-color: #F0F0F5; color: #111; }
        .stButton>button { background: #007AFF; color: #fff; }
        </style>
    """,
    "Neon Cyberpunk": """
        <style>
        body { background-color: #0D0D0D; color: #39FF14; }
        .stButton>button { background: #FF4D4D; color: #000; }
        </style>
    """
}

# ------------- SIDEBAR CONFIGURATION --------------
with st.sidebar:
    st.header("⚙️ Configurações 3eye IA Ultra Vision")
    api_key     = st.text_input("🔑 Binance API Key",     type="password", value=os.getenv("API_KEY_BINANCE",""))
    secret_key  = st.text_input("🔑 Binance Secret Key",  type="password", value=os.getenv("SECRET_KEY_BINANCE",""))
    openai_key  = st.text_input("🔑 OpenAI Key",          type="password", value=os.getenv("OPENAI_API_KEY",""))
    profile     = st.selectbox("👤 Perfil de Trading",    list(STRATS.keys()), index=list(STRATS.keys()).index("Multiplicação Divina"))
    exec_mode   = st.radio("🚀 Modo Execução",           ["Simulação","Real"])
    auto_mode   = st.checkbox("🤖 Executor IA-Auto")
    refresh     = st.slider("⏱️ Intervalo Atualização (s)", 5,60,10)
    trade_asset = st.selectbox("💰 Ativo Trade",         ["USDT","BTC","All"], index=0)
    theme       = st.selectbox("🎨 Tema Visual",         list(THEMES.keys()), index=0)
    if st.button("💾 Salvar Configurações"):
        set_key(".env","API_KEY_BINANCE",    api_key)
        set_key(".env","SECRET_KEY_BINANCE", secret_key)
        set_key(".env","OPENAI_API_KEY",     openai_key)
        st.success("✅ Configurações salvas! Recarregue.")
        st.stop()

# Apply theme CSS
if THEMES[theme]:
    st.markdown(THEMES[theme], unsafe_allow_html=True)

# Connect to Binance
exchange = None
if api_key and secret_key:
    try:
        exchange = ccxt.binance({'apiKey':api_key,'secret':secret_key,'enableRateLimit':True})
        exchange.load_markets()
        st.sidebar.success("✅ Binance conectada")
    except AuthenticationError as e:
        st.sidebar.error(f"❌ Auth Error: {e}")
    except Exception as e:
        st.sidebar.error(f"❌ Connection Error: {e}")

# Initialize OpenAI
if openai_key:
    openai.api_key = openai_key
    st.sidebar.success("✅ OpenAI configurado")

if 'entry_prices' not in st.session_state: st.session_state['entry_prices'] = {}
if 'daily_pnl' not in st.session_state: st.session_state['daily_pnl'] = 0
if 'performance' not in st.session_state: st.session_state['performance'] = []

# -------- TABS ---------
tabs = st.tabs([
    "Dashboard","Olho de Salomão","3eye Vision","IA Works",
    "Motor de Vidro","Execução","Backtesting","Histórico","Status",
    "Performance Geral","3eye Vision Avançada"
])

# 1) DASHBOARD
with tabs[0]:
    st.header("📊 Dashboard Completo")
    if exchange:
        bal = exchange.fetch_balance()
        bal_free = bal['free']
        spot_usdt = bal_free.get('USDT',0)
        spot_btc = bal_free.get('BTC',0)
        spot_brl = spot_usdt * (exchange.fetch_ticker("USDT/BRL")['last'] if "USDT/BRL" in exchange.symbols else 0)
        st.metric("Spot USDT", f"{spot_usdt:.2f}")
        st.metric("Spot BTC", f"{spot_btc:.6f}")
        st.metric("Spot BRL", f"{spot_brl:.2f}")
        # Mostra outros ativos relevantes
        st.write("Carteira Detalhada:")
        df_wallet = pd.DataFrame(
            [{"Ativo":k, "Qtd":v, "USDT":v*exchange.fetch_ticker(f"{k}/USDT")['last'] if f"{k}/USDT" in exchange.symbols else 0}
             for k,v in bal_free.items() if v > 0]
        )
        st.dataframe(df_wallet, use_container_width=True)
    else:
        st.info("🔌 Conecte sua conta Binance")

# 2) OLHO DE SALOMÃO
with tabs[1]:
    st.header("🔍 Olho de Salomão (On-Chain)")
    if exchange:
        all_pairs = [s for s in exchange.symbols if s.endswith('/USDT')]
        top6 = []
        scores = []
        for p in all_pairs[:33]:
            sent = solen_sentiment(p, exchange)
            rsi = compute_rsi(pd.DataFrame(exchange.fetch_ohlcv(p,'1h',limit=24),columns=['ts','open','high','low','close','vol'])['close']).iloc[-1]
            score = (sent=="Positiva")*2 + (rsi>60)*1 - (sent=="Negativa")*2
            scores.append({"Pair":p,"Sentimento":sent,"RSI":rsi,"Score":score})
        df_scores = pd.DataFrame(scores).sort_values("Score",ascending=False)
        top6 = df_scores.head(6)['Pair'].tolist()
        st.write("Moedas Top 6 do Momento:", ", ".join(top6))
        st.dataframe(df_scores, use_container_width=True)
        st.info("Clique em 'Colocar para Trade' nas moedas desejadas para usar no Executor IA-Auto.")
        if st.button("Colocar Top 6 para Trade"):
            st.session_state['auto_trade_pairs'] = top6
    else:
        st.info("🔌 Conecte Binance para ver sentimento")

# 3) 3EYE VISION (Real-Time Multi-Indicator Engine)
with tabs[2]:
    st.header("🧿 3eye Vision – Análise de 6 Moedas")
    if exchange:
        pairs = st.session_state.get('auto_trade_pairs', [s for s in exchange.symbols if s.endswith('/USDT')][:6])
        st.write("Moedas em foco:", ", ".join(pairs))
        for pair in pairs:
            df = pd.DataFrame(exchange.fetch_ohlcv(pair,'1h',limit=100),
                              columns=['ts','open','high','low','close','vol'])
            df['ts'] = pd.to_datetime(df['ts'],unit='ms')
            fig = go.Figure(data=[go.Candlestick(
                x=df['ts'], open=df['open'], high=df['high'],
                low=df['low'], close=df['close']
            )])
            fig.add_trace(go.Scatter(x=df['ts'], y=compute_rsi(df['close']), mode='lines', name='RSI'))
            fig.add_trace(go.Scatter(x=df['ts'], y=compute_macd(df['close'])[0], mode='lines', name='MACD'))
            st.plotly_chart(fig, use_container_width=True)
            # Probabilidade de trade: cruzamento de indicadores (exemplo simplificado)
            rsi = compute_rsi(df['close']).iloc[-1]
            macd, sig = compute_macd(df['close'])
            prob = (rsi>50)*0.4 + (macd.iloc[-1]>sig.iloc[-1])*0.6
            st.write(f"Probabilidade de trade: {prob*100:.0f}% (Base: RSI/MA/Trend)")
            st.info(f"Score de indicadores: RSI: {rsi:.2f} / MACD: {macd.iloc[-1]:.2f} / Sinal: {sig.iloc[-1]:.2f}")
            if st.button(f"Colocar {pair} para trading automático", key=f"trade_{pair}"):
                st.session_state['auto_trade_pairs'] = st.session_state.get('auto_trade_pairs', []) + [pair]
    else:
        st.info("🔌 Conecte Binance para visualizar gráficos")

# 4) IA WORKS
with tabs[3]:
    st.header("🤖 IA Works")
    st.write("Perfil de Trading:", profile)
    st.write("Modo Execução:", exec_mode)
    st.write("Executor IA-Auto:", "✅" if auto_mode else "❌")

# 5) MOTOR DE VIDRO
with tabs[4]:
    st.header("🔧 Motor de Vidro")
    if auto_mode and exchange:
        st_autorefresh(interval=refresh*1000, key="vidro")
        pairs = st.session_state.get('auto_trade_pairs', [s for s in exchange.symbols if s.endswith('/USDT')][:6])
        for p in pairs:
            st.write(f"{datetime.now().strftime('%H:%M:%S')} Lendo {p}")
    else:
        st.info("🤖 Ative o Executor IA-Auto")

# 6) EXECUÇÃO AUTOMÁTICA
with tabs[5]:
    st.header("⚙️ Execução Automática")
    
    if auto_mode and exchange:
        status = st.empty()
        status.info("Carregando dados…")

        pairs = st.session_state.get('auto_trade_pairs', [s for s in exchange.symbols if s.endswith('/USDT')][:6])
        status.info("Calculando sinais…")
        exec_records = []

        for p in pairs:
            try:
                df = pd.DataFrame(exchange.fetch_ohlcv(p, '1h', limit=50), columns=['ts', 'open', 'high', 'low', 'close', 'vol'])
                sent = solen_sentiment(p, exchange)
                action = STRATS[profile].signal(df, p, sent)
                price = df['close'].iloc[-1]

                if action == "buy":
                    st.session_state['entry_prices'][p] = price

                status.info("Proteções ativas…")

                if exec_mode == "Real" and action in ["buy", "sell"]:
                    bal = exchange.fetch_balance()

                    if trade_asset == "USDT":
                        size = (bal['free']['USDT'] / len(pairs)) / price
                    elif trade_asset == "BTC":
                        size = bal['free']['BTC'] / len(pairs)
                    else:
                        size = min(bal['free'].get('USDT', 0) / price, bal['free'].get('BTC', 0))

                    market = exchange.market(p)
                    min_amount = market['limits']['amount']['min']
                    min_notional = market['limits']['cost']['min']

                    if size < min_amount:
                        st.warning(f"🚫 {p}: tamanho {size:.4f} é menor que o mínimo permitido ({min_amount}). Ordem ignorada.")
                        continue

                    amt = float(exchange.amount_to_precision(p, size))
                    order_val = amt * price

                    if order_val < min_notional:
                        st.warning(f"⚠️ {p}: valor da ordem {order_val:.2f} abaixo do mínimo notional ({min_notional}). Ignorado.")
                        continue

                    # Cria ordem real com segurança
                    getattr(exchange, f"create_market_{action}_order")(p, amt)
                    st.success(f"✅ Ordem {action.upper()} executada para {p}: {amt:.4f} a {price:.2f}")

                exec_records.append({
                    "Par": p,
                    "Ação": action,
                    "Preço": price,
                    "Horário": datetime.now()
                })

            except (AuthenticationError, DDoSProtection) as e:
                st.error(f"❌ Erro Binance em {p}: {e}. Verifique API key, IP ou permissões.")
            except Exception as e:
                st.error(f"⚠️ Erro inesperado em {p}: {str(e)}")

        df_exec = pd.DataFrame(exec_records)
        st.table(df_exec)

        status.success("✅ Processo concluído!")

        # Calcula PnL da operação
        pnl = sum([r["Preço"] for r in exec_records if r["Ação"] == "sell"]) - \
              sum([r["Preço"] for r in exec_records if r["Ação"] == "buy"])

        st.session_state['performance'].append({
            "dt": datetime.now(),
            "PnL": pnl,
            "profile": profile
        })

    else:
        st.info("🤖 Ative Executor IA-Auto e conecte Binance")


# 7) BACKTESTING (Placeholder)
with tabs[6]:
    st.header("🔄 Backtesting Simplificado")
    st.info("Backtest module em desenvolvimento")

# 8) HISTÓRICO
with tabs[7]:
    st.header("📜 Histórico de Operações")
    st.write("Em breve, exportação completa de histórico.")

# 9) STATUS
with tabs[8]:
    st.header("🔧 Status Geral")
    st.write("Binance:", "✅" if exchange else "❌")
    st.write("OpenAI:", "✅" if openai_key else "❌")
    st.write("Perfil:", profile)
    st.write("Modo Execução:", exec_mode)
    st.write("Executor IA-Auto:", "✅" if auto_mode else "❌")
    st.write("Ativo de Trade:", trade_asset)
    st.write("Moedas em Trade:", st.session_state.get('auto_trade_pairs', []))
    if st.button("🔄 Atualizar Status"):
        st.experimental_rerun()

# 10) PERFORMANCE GERAL
with tabs[9]:
    st.header("📈 Painel de Performance")
    if st.session_state['performance']:
        df_perf = pd.DataFrame(st.session_state['performance'])
        st.line_chart(df_perf.set_index("dt")[["PnL"]])
        st.dataframe(df_perf, use_container_width=True)
    else:
        st.info("Sem dados de performance. Faça operações!")

# 11) 3EYE VISION AVANÇADA (Radar 6+33)
with tabs[10]:
    st.header("🧿 3eye Vision Avançada – Radar Inteligente 6+33")
    if exchange:
        all_pairs = [s for s in exchange.symbols if s.endswith('/USDT') and not s.startswith('BUSD')]
        data_scores = []
        for pair in all_pairs[:33]:
            df = pd.DataFrame(exchange.fetch_ohlcv(pair,'1h',limit=60),
                              columns=['ts','open','high','low','close','vol'])
            df['ts'] = pd.to_datetime(df['ts'],unit='ms')
            rsi = compute_rsi(df['close']).iloc[-1]
            macd, macd_sig = compute_macd(df['close'])
            macd_val = macd.iloc[-1] - macd_sig.iloc[-1]
            atr = compute_atr(df).iloc[-1]
            vol = df['vol'].iloc[-1]
            obv = compute_obv(df).iloc[-1]
            sentiment = solen_sentiment(pair, exchange)
            score = (
                (100-abs(rsi-50))/100 +
                (macd_val > 0) +
                (vol / df['vol'].mean() > 1.2) +
                (sentiment=="Positiva")*1.5 -
                (sentiment=="Negativa")*1.2
            )
            data_scores.append({"Par": pair, "RSI": rsi, "MACD": macd_val, "ATR": atr,
                               "Vol": vol, "Sentimento": sentiment, "Score": score})
        scores_df = pd.DataFrame(data_scores).sort_values("Score", ascending=False)
        st.dataframe(scores_df, use_container_width=True, hide_index=True)
        best6 = scores_df.head(6)["Par"].tolist()
        st.markdown("### Gráficos em Tempo Real das TOP 6")
        for p in best6:
            df = pd.DataFrame(exchange.fetch_ohlcv(p,'1h',limit=120),
                              columns=['ts','open','high','low','close','vol'])
            df['ts'] = pd.to_datetime(df['ts'],unit='ms')
            fig = go.Figure(data=[go.Candlestick(
                x=df['ts'], open=df['open'], high=df['high'],
                low=df['low'], close=df['close']
            )])
            fig.add_trace(go.Scatter(x=df['ts'], y=compute_rsi(df['close']), mode='lines', name='RSI'))
            fig.add_trace(go.Scatter(x=df['ts'], y=compute_macd(df['close'])[0], mode='lines', name='MACD'))
            st.plotly_chart(fig, use_container_width=True)
            st.write(f"**{p}** | Score 3eye: {scores_df.set_index('Par').loc[p]['Score']:.2f} | Sentimento: {scores_df.set_index('Par').loc[p]['Sentimento']}")
            if st.button(f"💰 Colocar {p} para trade automático", key=f"trade_{p}_av"):
                st.session_state['auto_trade_pairs'] = st.session_state.get('auto_trade_pairs', []) + [p]
        if st.button("⚡ Colocar automaticamente as 6 melhores para trade"):
            st.session_state['auto_trade_pairs'] = best6
        st.info("As moedas selecionadas serão usadas na próxima execução automática do Executor IA-Auto com o perfil ativo!")
    else:
        st.warning("🔌 Conecte sua conta Binance para usar o 3eye Vision Avançada.")

# ------------- AUTO OPEN BROWSER (opcional) -------------
if 'opened' not in st.session_state:
    st.session_state['opened'] = True
    webbrowser.open("http://localhost:8501")

# === CÓDIGO ADICIONAL FUNDIDO DO 1app.py ===
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import os
from datetime import datetime
from exchanges import BinanceConnector
import requests
from bs4 import BeautifulSoup

st.set_page_config(page_title="3eye Supreme Modular", layout="wide")

# --------- Dados Simulados (Mock) ---------
mock_bal = {
    "USDT": 10000, "BTC": 0.6, "ETH": 3.1, "SOL": 200, "XRP": 2200
}
mock_trades = [
    {"symbol": "BTC/USDT", "side": "buy", "price": 32000, "amount": 0.01, "datetime": "2024-06-01 10:30"},
    {"symbol": "ETH/USDT", "side": "sell", "price": 3200, "amount": 0.1, "datetime": "2024-06-01 11:00"},
]
mock_ohlcv = lambda: [[datetime.now().timestamp()*1000, 32000, 32500, 31900, 32400, 1] for _ in range(50)]

# --------- Onboarding Animado (igual antes) ---------
if 'onboarded' not in st.session_state:
    st.image("assets/3eye-logo-v2.png", width=120)
    st.title("Bem-vindo ao 3eye IA Supreme!")
    st.write("O sistema mais avançado de trading automático, macroanálise e gestão de ativos do mundo.")
    st.write("⚡ Siga o wizard para configurar e entender cada recurso:")
    st.markdown("""
    - Configure sua Exchange  
    - Escolha Perfis e Pesos  
    - Defina Alertas  
    - Conheça o Olho de Salomão  
    """)
    if st.button("Avançar"):
        st.session_state['onboarded'] = True
    st.stop()

# -------- Sidebar Completa (com "Salvar"/mock) ---------
st.sidebar.header("⚙️ Configuração")
exchange_name = st.sidebar.selectbox("Exchange", ["Binance"])
api_key = st.sidebar.text_input("API Key", type="password", help="Chave da sua exchange")
api_secret = st.sidebar.text_input("API Secret", type="password", help="Chave secreta")
profile = st.sidebar.multiselect("Perfis de Trading", ["Conservador","Agressivo","Multiplicação Divina","IA Power","Harmônico","Custom"], default=["Multiplicação Divina"])
weights = st.sidebar.slider("Peso dos Perfis (soma 100)", 0, 100, 50, step=10)
mode = st.sidebar.radio("Modo", ["Simulação", "Real"])
theme = st.sidebar.selectbox("Tema", ["Apple", "Neon", "Glass", "Dark"])
show_futures = st.sidebar.checkbox("Mostrar também Futures/Margin", value=False)
auto_refresh = st.sidebar.slider("AutoRefresh (s)", 5, 60, 20)

if st.sidebar.button("Salvar/Conectar"):
    if api_key and api_secret:
        try:
            connector = BinanceConnector(api_key, api_secret)
            st.session_state['connector'] = connector
            st.success("Conectado com sucesso à Binance!")
        except Exception as e:
            st.error(f"Erro na conexão: {e}")
    else:
        st.session_state['connector'] = None
        st.info("Salvando dados em modo simulação.")

connector = st.session_state.get('connector', None)
using_mock = connector is None

# --------- Função para buscar dados reais ou simulados ---------
def get_balance():
    return connector.fetch_balance()['total'] if connector else mock_bal

def get_trades():
    return pd.DataFrame(connector.fetch_spot_trades()) if connector else pd.DataFrame(mock_trades)

def get_ohlcv(symbol):
    if connector:
        return pd.DataFrame(connector.fetch_ohlcv(symbol, '1h', 50), columns=['ts','open','high','low','close','vol'])
    else:
        return pd.DataFrame(mock_ohlcv(), columns=['ts','open','high','low','close','vol'])

# -------- Onboarding Animado ---------
if 'onboarded' not in st.session_state:
    st.image("assets/3eye-logo-v2.png", width=120)
    st.title("Bem-vindo ao 3eye IA Supreme!")
    st.write("O sistema mais avançado de trading automático, macroanálise e gestão de ativos do mundo.")
    st.write("⚡ Siga o wizard para configurar e entender cada recurso:")
    st.markdown("""
    - Configure sua Exchange  
    - Escolha Perfis e Pesos  
    - Defina Alertas  
    - Conheça o Olho de Salomão  
    """)
    if st.button("Avançar"):
        st.session_state['onboarded'] = True
    st.stop()

# -------- Sidebar Completa ---------
st.sidebar.header("⚙️ Configuração")
exchange_name = st.sidebar.selectbox("Exchange", ["Binance"], key="sidebar_exchange")
api_key = st.sidebar.text_input("API Key", type="password", help="Chave da sua exchange")
api_secret = st.sidebar.text_input("API Secret", type="password", help="Chave secreta")
profile = st.sidebar.multiselect("Perfis de Trading", ["Conservador","Agressivo","Multiplicação Divina","IA Power","Harmônico","Custom"], default=["Multiplicação Divina"])
weights = st.sidebar.slider("Peso dos Perfis (soma 100)", 0, 100, 50, step=10)
mode = st.sidebar.radio("Modo", ["Simulação", "Real"])
theme = st.sidebar.selectbox("Tema", ["Apple", "Neon", "Glass", "Dark"])
show_futures = st.sidebar.checkbox("Mostrar também Futures/Margin", value=False)
auto_refresh = st.sidebar.slider("AutoRefresh (s)", 5, 60, 20)
if st.sidebar.button("Salvar/Conectar"):
    st.session_state['connector'] = None
    try:
        if exchange_name == "Binance":
            connector = BinanceConnector(api_key, api_secret)
            st.session_state['connector'] = connector
            st.success("Conectado com sucesso à Binance!")
    except Exception as e:
        st.error(f"Erro na conexão: {e}")

connector = st.session_state.get('connector', None)
if not connector:
    st.info("Conecte sua exchange para visualizar dados.")

# -------- Funções Auxiliares --------
def scrape_crypto_news():
    """Scraping de notícias das principais fontes (exemplo: CoinTelegraph, Google News)"""
    try:
        url = "https://cointelegraph.com/tags/cryptocurrencies"
        res = requests.get(url, timeout=5)
        soup = BeautifulSoup(res.text, 'html.parser')
        headlines = [x.get_text() for x in soup.select('span.post-card-inline__title')][:6]
        return headlines
    except Exception as e:
        return ["Notícia não disponível"]

# --------- Main Tabs ---------------
tabs = st.tabs([
    "Dashboard", "Operações", "Carteira", "Top6 Ativos", "3eye Vision", "Olho de Salomão", "Logs & Replay", "Manual"
])

# --------- Dashboard Visual ---------
with tabs[0]:
    st.title("3eye Dashboard 📊")
    if connector:
        bal = connector.fetch_balance()
        wallet = bal['total']
        # Bloco superior
        cols = st.columns([1,1,1,1])
        cols[0].metric("USDT", f"{wallet.get('USDT',0):,.2f}")
        cols[1].metric("BTC", f"{wallet.get('BTC',0):,.4f}")
        cols[2].metric("ETH", f"{wallet.get('ETH',0):,.4f}")
        # Saldo em BRL/USDT (exemplo)
        btc_usdt = connector.fetch_ticker("BTC/USDT")['last']
        usd_brl = connector.fetch_ticker("USDT/BRL")['last'] if "USDT/BRL" in connector.exchange.symbols else 5.2
        saldo_total = sum(wallet[k]*connector.fetch_ticker(f"{k}/USDT")['last']
                          if f"{k}/USDT" in connector.exchange.symbols else 0 for k in wallet)
        cols[3].metric("Saldo Total (BRL)", f"R${saldo_total*usd_brl:,.2f}")

        # Pie Chart Distribuição
        dfpie = pd.DataFrame({"Moeda":list(wallet.keys()), "Valor":list(wallet.values())})
        fig_pie = go.Figure(data=[go.Pie(labels=dfpie['Moeda'], values=dfpie['Valor'])])
        st.plotly_chart(fig_pie, use_container_width=True)

        # Últimas ordens SPOT
        st.subheader("Operações Recentes (Spot)")
        df_trades = pd.DataFrame(connector.fetch_spot_trades())
        if not df_trades.empty:
            st.dataframe(df_trades.tail(10))
        else:
            st.info("Sem trades recentes.")

        # Heatmap de lucros/prejuízos (exemplo)
        # [Requer log de trades estruturado, pode ser implementado depois]
        st.subheader("Notícias do Mercado")
        news = scrape_crypto_news()
        for n in news:
            st.info(n)

    else:
        st.info("Conecte a Exchange para ver o Dashboard.")

# --------- Operações Tab -----------
with tabs[1]:
    st.header("Histórico Operações & Heatmap")
    if connector:
        df_trades = pd.DataFrame(connector.fetch_spot_trades())
        if not df_trades.empty:
            st.dataframe(df_trades)
        else:
            st.info("Sem trades recentes.")
    else:
        st.info("Conecte a Exchange.")

# --------- Carteira Detalhada -------
with tabs[2]:
    st.header("Carteira Completa")
    if connector:
        bal = connector.fetch_balance()
        st.json(bal)
    else:
        st.info("Conecte a Exchange.")

# --------- Top6 Ativos/Seleção ------
with tabs[3]:
    st.header("Top 6 Ativos Selecionados")
    mode6 = st.radio("Seleção dos 6", ["Score IA", "Volume", "Manual"])
    # Exemplo: seleciona manualmente, pode puxar pelo score/volume depois
    if connector:
        symbols = [s for s in connector.exchange.symbols if s.endswith("/USDT")]
        top6 = symbols[:6] if mode6 != "Manual" else st.multiselect("Selecione os 6", symbols, default=symbols[:6])
        for ativo in top6:
            st.markdown(f"#### {ativo}")
            df = pd.DataFrame(connector.fetch_ohlcv(ativo, '1h', 50), columns=['ts','open','high','low','close','vol'])
            df['ts'] = pd.to_datetime(df['ts'], unit='ms')
            fig = go.Figure(data=[go.Candlestick(
                x=df['ts'], open=df['open'], high=df['high'],
                low=df['low'], close=df['close']
            )])
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Conecte a Exchange.")

# --------- 3eye Vision (Indicadores) -----
with tabs[4]:
    st.header("3eye Vision – Cruzamento de Indicadores")
    if connector:
        symbols = [s for s in connector.exchange.symbols if s.endswith("/USDT")][:6]
        for pair in symbols:
            df = pd.DataFrame(connector.fetch_ohlcv(pair, '1h', 50), columns=['ts','open','high','low','close','vol'])
            df['ts'] = pd.to_datetime(df['ts'], unit='ms')
            # RSI (simples)
            df['rsi'] = df['close'].diff().rolling(14).mean()
            # MACD (simplificado)
            df['macd'] = df['close'].ewm(12).mean() - df['close'].ewm(26).mean()
            fig = go.Figure(data=[go.Candlestick(
                x=df['ts'], open=df['open'], high=df['high'],
                low=df['low'], close=df['close']
            )])
            fig.add_trace(go.Scatter(x=df['ts'], y=df['rsi'], mode='lines', name='RSI'))
            fig.add_trace(go.Scatter(x=df['ts'], y=df['macd'], mode='lines', name='MACD'))
            st.plotly_chart(fig, use_container_width=True)
            st.write(df[['ts','close','rsi','macd']].tail(5))
    else:
        st.info("Conecte a Exchange.")

# --------- Olho de Salomão (Sentimento Macro) -----
with tabs[5]:
    st.header("Olho de Salomão – Análise Macro")
    st.write("Scraping de notícias, resumo macro, status IA, score de sentimento etc.")
    news = scrape_crypto_news()
    for n in news:
        st.warning(n)
    st.info("🚀 (Em breve: análise automática de impacto por IA para cada ativo da carteira.)")

# --------- Logs & Replay/Manual -----
with tabs[6]:
    st.header("Logs, Replay e AutoML")
    st.write("Aqui ficam os logs das ordens, sinais, score IA e replay de operações (AutoML).")
    st.info("Módulo em construção – personalizável.")

# --------- Manual Completo (help/tooltips) -----
with tabs[7]:
    st.header("Manual 3eye Supreme – Funções e Dicas")
    st.write("""
    - **Onboarding**: Primeira tela animada que explica os recursos e o fluxo ideal de configuração.
    - **Sidebar**: Configure exchange, perfil, pesos, modo (real/simulado), tema e auto-refresh.
    - **Dashboard**: Resumo visual da carteira, distribuição dos ativos, lucros e operações recentes.
    - **Operações**: Log detalhado das operações executadas (Spot, com opção para Futures/Margin).
    - **Carteira**: Exibe todos ativos, saldos e métricas detalhadas.
    - **Top6 Ativos**: Seleção dos 6 ativos principais, por score IA, volume ou manualmente.
    - **3eye Vision**: Gráficos em tempo real, análise cruzada de indicadores técnicos.
    - **Olho de Salomão**: Sentimento macro, impacto de notícias, alertas globais.
    - **Logs & Replay**: Histórico completo, replays, AutoML para ajustar parâmetros.
    - **Manual**: Esta seção, com dicas, exemplos e explicação de cada função.
    - **Segurança**: (Recomenda-se usar autenticação 2FA na exchange, nunca compartilhe sua chave!)
    """)
    st.info("Passe o mouse nos botões e funções: sempre mostro uma dica de uso!")

# --------- Autorefresh Simples ----------

# === EXTENSÕES DO APP ULTIMATE ===


# 12) GPT-4 Comando Natural para Controle do Sistema
if openai_key:
    with st.sidebar.expander("💬 GPT-4: Comando Inteligente"):
        user_input = st.text_area("Digite seu comando para o sistema (GPT-4)", "")
        if st.button("Executar GPT-4"):
            if user_input:
                prompt = f"""
Você é um assistente de IA conectado ao sistema 3eye Supreme. Responda de forma precisa e concisa, com base nos comandos abaixo do usuário. 
Você pode sugerir modificações no perfil de trading, ativar/desativar modos, selecionar ativos, exibir dados ou explicar estratégias.

Comando recebido:
{user_input}

Estado atual:
Perfil: {profile}
Modo Execução: {exec_mode}
Auto-Auto: {'Ativo' if auto_mode else 'Inativo'}
Ativo de Trade: {trade_asset}
Tema: {theme}
Moedas em trade: {', '.join(st.session_state.get('auto_trade_pairs', []))}

Responda com a ação sugerida e explicação técnica.
"""
                try:
                    response = openai.ChatCompletion.create(
                        model="gpt-4",
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.5
                    )
                    output = response['choices'][0]['message']['content']
                    st.success("GPT-4 respondeu:")
                    st.markdown(output)
                except Exception as e:
                    st.error(f"Erro ao conectar com GPT-4: {e}")
else:
    st.warning("🔐 Adicione sua OpenAI Key para usar o Comando GPT-4")

import time
if st.session_state.get('onboarded', False):
    st_autorefresh = st.experimental_rerun if auto_refresh > 0 else lambda: None
    if 'last_refresh' not in st.session_state or \
       (datetime.now() - st.session_state.get('last_refresh', datetime.now())).seconds > auto_refresh:
        st.session_state['last_refresh'] = datetime.now()
        st_autorefresh()

# ==============================
# Código Fundido (2º arquivo)
# ==============================

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
import os
from datetime import datetime
from exchanges import BinanceConnector
import requests
from bs4 import BeautifulSoup

st.set_page_config(page_title="3eye Supreme Modular", layout="wide")

# --------- Dados Simulados (Mock) ---------
mock_bal = {
    "USDT": 10000, "BTC": 0.6, "ETH": 3.1, "SOL": 200, "XRP": 2200
}
mock_trades = [
    {"symbol": "BTC/USDT", "side": "buy", "price": 32000, "amount": 0.01, "datetime": "2024-06-01 10:30"},
    {"symbol": "ETH/USDT", "side": "sell", "price": 3200, "amount": 0.1, "datetime": "2024-06-01 11:00"},
]
mock_ohlcv = lambda: [[datetime.now().timestamp()*1000, 32000, 32500, 31900, 32400, 1] for _ in range(50)]

# --------- Onboarding Animado (igual antes) ---------
if 'onboarded' not in st.session_state:
    st.image("assets/3eye-logo-v2.png", width=120)
    st.title("Bem-vindo ao 3eye IA Supreme!")
    st.write("O sistema mais avançado de trading automático, macroanálise e gestão de ativos do mundo.")
    st.write("⚡ Siga o wizard para configurar e entender cada recurso:")
    st.markdown("""
    - Configure sua Exchange  
    - Escolha Perfis e Pesos  
    - Defina Alertas  
    - Conheça o Olho de Salomão  
    """)
    if st.button("Avançar"):
        st.session_state['onboarded'] = True
    st.stop()

# -------- Sidebar Completa (com "Salvar"/mock) ---------
st.sidebar.header("⚙️ Configuração")
exchange_name = st.sidebar.selectbox("Exchange", ["Binance"])
api_key = st.sidebar.text_input("API Key", type="password", help="Chave da sua exchange")
api_secret = st.sidebar.text_input("API Secret", type="password", help="Chave secreta")
profile = st.sidebar.multiselect("Perfis de Trading", ["Conservador","Agressivo","Multiplicação Divina","IA Power","Harmônico","Custom"], default=["Multiplicação Divina"])
weights = st.sidebar.slider("Peso dos Perfis (soma 100)", 0, 100, 50, step=10)
mode = st.sidebar.radio("Modo", ["Simulação", "Real"])
theme = st.sidebar.selectbox("Tema", ["Apple", "Neon", "Glass", "Dark"])
show_futures = st.sidebar.checkbox("Mostrar também Futures/Margin", value=False)
auto_refresh = st.sidebar.slider("AutoRefresh (s)", 5, 60, 20)

if st.sidebar.button("Salvar/Conectar"):
    if api_key and api_secret:
        try:
            connector = BinanceConnector(api_key, api_secret)
            st.session_state['connector'] = connector
            st.success("Conectado com sucesso à Binance!")
        except Exception as e:
            st.error(f"Erro na conexão: {e}")
    else:
        st.session_state['connector'] = None
        st.info("Salvando dados em modo simulação.")

connector = st.session_state.get('connector', None)
using_mock = connector is None

# --------- Função para buscar dados reais ou simulados ---------
def get_balance():
    return connector.fetch_balance()['total'] if connector else mock_bal

def get_trades():
    return pd.DataFrame(connector.fetch_spot_trades()) if connector else pd.DataFrame(mock_trades)

def get_ohlcv(symbol):
    if connector:
        return pd.DataFrame(connector.fetch_ohlcv(symbol, '1h', 50), columns=['ts','open','high','low','close','vol'])
    else:
        return pd.DataFrame(mock_ohlcv(), columns=['ts','open','high','low','close','vol'])

# -------- Onboarding Animado ---------
if 'onboarded' not in st.session_state:
    st.image("assets/3eye-logo-v2.png", width=120)
    st.title("Bem-vindo ao 3eye IA Supreme!")
    st.write("O sistema mais avançado de trading automático, macroanálise e gestão de ativos do mundo.")
    st.write("⚡ Siga o wizard para configurar e entender cada recurso:")
    st.markdown("""
    - Configure sua Exchange  
    - Escolha Perfis e Pesos  
    - Defina Alertas  
    - Conheça o Olho de Salomão  
    """)
    if st.button("Avançar"):
        st.session_state['onboarded'] = True
    st.stop()

# -------- Sidebar Completa ---------
st.sidebar.header("⚙️ Configuração")
exchange_name = st.sidebar.selectbox("Exchange", ["Binance"], key="sidebar_exchange")
api_key = st.sidebar.text_input("API Key", type="password", help="Chave da sua exchange")
api_secret = st.sidebar.text_input("API Secret", type="password", help="Chave secreta")
profile = st.sidebar.multiselect("Perfis de Trading", ["Conservador","Agressivo","Multiplicação Divina","IA Power","Harmônico","Custom"], default=["Multiplicação Divina"])
weights = st.sidebar.slider("Peso dos Perfis (soma 100)", 0, 100, 50, step=10)
mode = st.sidebar.radio("Modo", ["Simulação", "Real"])
theme = st.sidebar.selectbox("Tema", ["Apple", "Neon", "Glass", "Dark"])
show_futures = st.sidebar.checkbox("Mostrar também Futures/Margin", value=False)
auto_refresh = st.sidebar.slider("AutoRefresh (s)", 5, 60, 20)
if st.sidebar.button("Salvar/Conectar"):
    st.session_state['connector'] = None
    try:
        if exchange_name == "Binance":
            connector = BinanceConnector(api_key, api_secret)
            st.session_state['connector'] = connector
            st.success("Conectado com sucesso à Binance!")
    except Exception as e:
        st.error(f"Erro na conexão: {e}")

connector = st.session_state.get('connector', None)
if not connector:
    st.info("Conecte sua exchange para visualizar dados.")

# -------- Funções Auxiliares --------
def scrape_crypto_news():
    """Scraping de notícias das principais fontes (exemplo: CoinTelegraph, Google News)"""
    try:
        url = "https://cointelegraph.com/tags/cryptocurrencies"
        res = requests.get(url, timeout=5)
        soup = BeautifulSoup(res.text, 'html.parser')
        headlines = [x.get_text() for x in soup.select('span.post-card-inline__title')][:6]
        return headlines
    except Exception as e:
        return ["Notícia não disponível"]

# --------- Main Tabs ---------------
tabs = st.tabs([
    "Dashboard", "Operações", "Carteira", "Top6 Ativos", "3eye Vision", "Olho de Salomão", "Logs & Replay", "Manual"
])

# --------- Dashboard Visual ---------
with tabs[0]:
    st.title("3eye Dashboard 📊")
    if connector:
        bal = connector.fetch_balance()
        wallet = bal['total']
        # Bloco superior
        cols = st.columns([1,1,1,1])
        cols[0].metric("USDT", f"{wallet.get('USDT',0):,.2f}")
        cols[1].metric("BTC", f"{wallet.get('BTC',0):,.4f}")
        cols[2].metric("ETH", f"{wallet.get('ETH',0):,.4f}")
        # Saldo em BRL/USDT (exemplo)
        btc_usdt = connector.fetch_ticker("BTC/USDT")['last']
        usd_brl = connector.fetch_ticker("USDT/BRL")['last'] if "USDT/BRL" in connector.exchange.symbols else 5.2
        saldo_total = sum(wallet[k]*connector.fetch_ticker(f"{k}/USDT")['last']
                          if f"{k}/USDT" in connector.exchange.symbols else 0 for k in wallet)
        cols[3].metric("Saldo Total (BRL)", f"R${saldo_total*usd_brl:,.2f}")

        # Pie Chart Distribuição
        dfpie = pd.DataFrame({"Moeda":list(wallet.keys()), "Valor":list(wallet.values())})
        fig_pie = go.Figure(data=[go.Pie(labels=dfpie['Moeda'], values=dfpie['Valor'])])
        st.plotly_chart(fig_pie, use_container_width=True)

        # Últimas ordens SPOT
        st.subheader("Operações Recentes (Spot)")
        df_trades = pd.DataFrame(connector.fetch_spot_trades())
        if not df_trades.empty:
            st.dataframe(df_trades.tail(10))
        else:
            st.info("Sem trades recentes.")

        # Heatmap de lucros/prejuízos (exemplo)
        # [Requer log de trades estruturado, pode ser implementado depois]
        st.subheader("Notícias do Mercado")
        news = scrape_crypto_news()
        for n in news:
            st.info(n)

    else:
        st.info("Conecte a Exchange para ver o Dashboard.")

# --------- Operações Tab -----------
with tabs[1]:
    st.header("Histórico Operações & Heatmap")
    if connector:
        df_trades = pd.DataFrame(connector.fetch_spot_trades())
        if not df_trades.empty:
            st.dataframe(df_trades)
        else:
            st.info("Sem trades recentes.")
    else:
        st.info("Conecte a Exchange.")

# --------- Carteira Detalhada -------
with tabs[2]:
    st.header("Carteira Completa")
    if connector:
        bal = connector.fetch_balance()
        st.json(bal)
    else:
        st.info("Conecte a Exchange.")

# --------- Top6 Ativos/Seleção ------
with tabs[3]:
    st.header("Top 6 Ativos Selecionados")
    mode6 = st.radio("Seleção dos 6", ["Score IA", "Volume", "Manual"])
    # Exemplo: seleciona manualmente, pode puxar pelo score/volume depois
    if connector:
        symbols = [s for s in connector.exchange.symbols if s.endswith("/USDT")]
        top6 = symbols[:6] if mode6 != "Manual" else st.multiselect("Selecione os 6", symbols, default=symbols[:6])
        for ativo in top6:
            st.markdown(f"#### {ativo}")
            df = pd.DataFrame(connector.fetch_ohlcv(ativo, '1h', 50), columns=['ts','open','high','low','close','vol'])
            df['ts'] = pd.to_datetime(df['ts'], unit='ms')
            fig = go.Figure(data=[go.Candlestick(
                x=df['ts'], open=df['open'], high=df['high'],
                low=df['low'], close=df['close']
            )])
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Conecte a Exchange.")

# --------- 3eye Vision (Indicadores) -----
with tabs[4]:
    st.header("3eye Vision – Cruzamento de Indicadores")
    if connector:
        symbols = [s for s in connector.exchange.symbols if s.endswith("/USDT")][:6]
        for pair in symbols:
            df = pd.DataFrame(connector.fetch_ohlcv(pair, '1h', 50), columns=['ts','open','high','low','close','vol'])
            df['ts'] = pd.to_datetime(df['ts'], unit='ms')
            # RSI (simples)
            df['rsi'] = df['close'].diff().rolling(14).mean()
            # MACD (simplificado)
            df['macd'] = df['close'].ewm(12).mean() - df['close'].ewm(26).mean()
            fig = go.Figure(data=[go.Candlestick(
                x=df['ts'], open=df['open'], high=df['high'],
                low=df['low'], close=df['close']
            )])
            fig.add_trace(go.Scatter(x=df['ts'], y=df['rsi'], mode='lines', name='RSI'))
            fig.add_trace(go.Scatter(x=df['ts'], y=df['macd'], mode='lines', name='MACD'))
            st.plotly_chart(fig, use_container_width=True)
            st.write(df[['ts','close','rsi','macd']].tail(5))
    else:
        st.info("Conecte a Exchange.")

# --------- Olho de Salomão (Sentimento Macro) -----
with tabs[5]:
    st.header("Olho de Salomão – Análise Macro")
    st.write("Scraping de notícias, resumo macro, status IA, score de sentimento etc.")
    news = scrape_crypto_news()
    for n in news:
        st.warning(n)
    st.info("🚀 (Em breve: análise automática de impacto por IA para cada ativo da carteira.)")

# --------- Logs & Replay/Manual -----
with tabs[6]:
    st.header("Logs, Replay e AutoML")
    st.write("Aqui ficam os logs das ordens, sinais, score IA e replay de operações (AutoML).")
    st.info("Módulo em construção – personalizável.")

# --------- Manual Completo (help/tooltips) -----
with tabs[7]:
    st.header("Manual 3eye Supreme – Funções e Dicas")
    st.write("""
    - **Onboarding**: Primeira tela animada que explica os recursos e o fluxo ideal de configuração.
    - **Sidebar**: Configure exchange, perfil, pesos, modo (real/simulado), tema e auto-refresh.
    - **Dashboard**: Resumo visual da carteira, distribuição dos ativos, lucros e operações recentes.
    - **Operações**: Log detalhado das operações executadas (Spot, com opção para Futures/Margin).
    - **Carteira**: Exibe todos ativos, saldos e métricas detalhadas.
    - **Top6 Ativos**: Seleção dos 6 ativos principais, por score IA, volume ou manualmente.
    - **3eye Vision**: Gráficos em tempo real, análise cruzada de indicadores técnicos.
    - **Olho de Salomão**: Sentimento macro, impacto de notícias, alertas globais.
    - **Logs & Replay**: Histórico completo, replays, AutoML para ajustar parâmetros.
    - **Manual**: Esta seção, com dicas, exemplos e explicação de cada função.
    - **Segurança**: (Recomenda-se usar autenticação 2FA na exchange, nunca compartilhe sua chave!)
    """)
    st.info("Passe o mouse nos botões e funções: sempre mostro uma dica de uso!")

# --------- Autorefresh Simples ----------

# === EXTENSÕES DO APP ULTIMATE ===


# 12) GPT-4 Comando Natural para Controle do Sistema
if openai_key:
    with st.sidebar.expander("💬 GPT-4: Comando Inteligente"):
        user_input = st.text_area("Digite seu comando para o sistema (GPT-4)", "")
        if st.button("Executar GPT-4"):
            if user_input:
                prompt = f"""
Você é um assistente de IA conectado ao sistema 3eye Supreme. Responda de forma precisa e concisa, com base nos comandos abaixo do usuário. 
Você pode sugerir modificações no perfil de trading, ativar/desativar modos, selecionar ativos, exibir dados ou explicar estratégias.

Comando recebido:
{user_input}

Estado atual:
Perfil: {profile}
Modo Execução: {exec_mode}
Auto-Auto: {'Ativo' if auto_mode else 'Inativo'}
Ativo de Trade: {trade_asset}
Tema: {theme}
Moedas em trade: {', '.join(st.session_state.get('auto_trade_pairs', []))}

Responda com a ação sugerida e explicação técnica.
"""
                try:
                    response = openai.ChatCompletion.create(
                        model="gpt-4",
                        messages=[{"role": "user", "content": prompt}],
                        temperature=0.5
                    )
                    output = response['choices'][0]['message']['content']
                    st.success("GPT-4 respondeu:")
                    st.markdown(output)
                except Exception as e:
                    st.error(f"Erro ao conectar com GPT-4: {e}")
else:
    st.warning("🔐 Adicione sua OpenAI Key para usar o Comando GPT-4")

import time
if st.session_state.get('onboarded', False):
    st_autorefresh = st.experimental_rerun if auto_refresh > 0 else lambda: None
    if 'last_refresh' not in st.session_state or \
       (datetime.now() - st.session_state.get('last_refresh', datetime.now())).seconds > auto_refresh:
        st.session_state['last_refresh'] = datetime.now()
        st_autorefresh()