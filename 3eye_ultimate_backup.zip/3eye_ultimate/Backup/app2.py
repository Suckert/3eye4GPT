import streamlit as st
import pandas as pd
import os
import openai
from dotenv import set_key, load_dotenv
import requests

from utils import salvar_historico_operacoes, carregar_historico_operacoes, exportar_periodo, reset_history
from indicators import compute_rsi, compute_atr
from strategies import STRATS, profile_info
from exchanges.binance import BinanceConnector
from ai.salomao import obter_top_ativos_salomao, exibir_racional_ia
from manual.manual import manual_tab
from backtest.backtest import backtest_tab

# ----- CONFIGURANDO .env -----
load_dotenv(".env")

st.set_page_config(page_title="3eye IA Ultimate", layout="wide")

# --- SIDEBAR CONFIGURÁVEL ---
st.sidebar.header("⚙️ Configurações Gerais")

api_key_binance = st.sidebar.text_input("Binance API Key", type="password", value=os.getenv("API_KEY_BINANCE", ""))
secret_key_binance = st.sidebar.text_input("Binance Secret Key", type="password", value=os.getenv("SECRET_KEY_BINANCE", ""))
openai_api_key = st.sidebar.text_input("OpenAI API Key", type="password", value=os.getenv("OPENAI_API_KEY", ""))

if st.sidebar.button("💾 Salvar Configurações"):
    set_key(".env", "API_KEY_BINANCE", api_key_binance)
    set_key(".env", "SECRET_KEY_BINANCE", secret_key_binance)
    set_key(".env", "OPENAI_API_KEY", openai_api_key)
    openai.api_key = openai_api_key
    st.sidebar.success("Configurações salvas no .env! Recarregue o app para aplicar.")

openai.api_key = openai_api_key

# ----- Consulta saldo OpenAI -----
def consultar_saldo_openai(api_key):
    url = "https://api.openai.com/dashboard/billing/credit_grants"
    headers = {
        "Authorization": f"Bearer {api_key}"
    }
    try:
        r = requests.get(url, headers=headers, timeout=15)
        if r.status_code == 200:
            saldo = r.json().get("total_available", 0.0)
            return saldo
        elif r.status_code == 401:
            st.error("Chave OpenAI inválida. Corrija na barra lateral.")
            return None
        else:
            st.warning("Não foi possível verificar saldo OpenAI (API retornou código diferente de 200).")
            return None
    except Exception as e:
        st.warning(f"Erro ao consultar saldo da OpenAI: {e}")
        return None

# Mostra saldo OpenAI na sidebar
saldo_openai = consultar_saldo_openai(openai_api_key)
if saldo_openai is not None:
    st.sidebar.markdown(f"💳 **Saldo OpenAI API:** ${saldo_openai:.2f}")
    if saldo_openai <= 0:
        st.sidebar.error("Seu saldo da OpenAI API está zerado! Recarregue créditos para continuar usando IA.")
else:
    st.sidebar.warning("Não foi possível checar saldo da OpenAI API.")

# ----- Conector Binance -----
exchange = BinanceConnector(api_key_binance, secret_key_binance) if api_key_binance and secret_key_binance else None

theme = st.sidebar.selectbox("Tema", ["Dark", "Neon", "Light"])

# ----- Lista de Ativos -----
ativos_analise = [
    "BTC/USDT","ETH/USDT","BNB/USDT","SOL/USDT","XRP/USDT","ADA/USDT","DOGE/USDT","AVAX/USDT",
    "DOT/USDT","LINK/USDT","TRX/USDT","LTC/USDT","MATIC/USDT","UNI/USDT","ATOM/USDT",
    "OP/USDT","SUI/USDT","INJ/USDT","RNDR/USDT","ARB/USDT","FIL/USDT","PEPE/USDT","BLUR/USDT",
    "SEI/USDT","TIA/USDT","SHIB/USDT","JUP/USDT","PYTH/USDT","APT/USDT",
    "FET/USDT","GMT/USDT","GMX/USDT"
]

# ----- IA Olho de Salomão -----
if saldo_openai is not None and saldo_openai <= 0:
    st.warning("A IA está pausada porque sua API está sem créditos. Recarregue créditos para reativar o Olho de Salomão.")
    scores = {ativo: 5 for ativo in ativos_analise}
    racional = "IA pausada: notas neutras atribuídas."
else:
    scores, racional = obter_top_ativos_salomao(ativos_analise)

default_seis = [x[0] for x in sorted(scores.items(), key=lambda x: x[1], reverse=True)[:6]]
ativos_escolhidos = st.sidebar.multiselect(
    "Selecione até 6 ativos", ativos_analise, default=default_seis, max_selections=6
)

tabs = st.tabs([
    "Dashboard", "Olho de Salomão", "Execução", "Motor de Vidro", "Histórico", "Manual", "Backtest"
])

# 1. DASHBOARD PRINCIPAL
with tabs[0]:
    st.title("📈 Dashboard das 6 Moedas Selecionadas")
    if not ativos_escolhidos:
        st.warning("Selecione ao menos 1 ativo no Olho de Salomão!")
    else:
        for ativo in ativos_escolhidos:
            df = exchange.fetch_ohlcv_df(ativo) if exchange else None
            if df is not None:
                st.subheader(ativo)
                st.line_chart(df['close'])
                st.write(f"RSI: {compute_rsi(df['close']).iloc[-1]:.2f} | ATR: {compute_atr(df).iloc[-1]:.2f}")
            else:
                st.error("Conecte sua conta Binance.")

# 2. OLHO DE SALOMÃO
with tabs[1]:
    st.header("🔮 Olho de Salomão – IA Sábia das Criptos")
    st.dataframe(pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota IA"]).sort_values("Nota IA", ascending=False))
    st.markdown("#### Motivo da escolha (IA):")
    exibir_racional_ia(racional)

# 3. EXECUÇÃO
with tabs[2]:
    st.header("⚡ Execução Automática")
    st.info("Aqui você executa ordens automáticas/manual nas 6 moedas selecionadas (em breve, IA ao vivo).")

# 4. MOTOR DE VIDRO (logs ao vivo)
with tabs[3]:
    st.header("🟢 Motor de Vidro – Logs em Tempo Real")
    st.info("Aqui aparecerão logs, decisões e diagnósticos da IA em tempo real.")

# 5. HISTÓRICO DE OPERAÇÕES
with tabs[4]:
    st.header("📜 Histórico de Operações")
    df_hist = carregar_historico_operacoes()
    st.dataframe(df_hist)
    st.download_button("Exportar CSV", df_hist.to_csv(index=False), file_name="historico_3eye.csv", mime='text/csv')
    exportar_periodo(df_hist)
    if st.button("Resetar histórico"):
        reset_history()
        st.experimental_rerun()

# 6. MANUAL & GLOSSÁRIO
with tabs[5]:
    manual_tab()

# 7. BACKTEST
with tabs[6]:
    backtest_tab()

