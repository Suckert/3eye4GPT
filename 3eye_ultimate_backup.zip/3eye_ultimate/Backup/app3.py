import streamlit as st
st.set_page_config(page_title="3eye IA Ultimate", layout="wide")

import pandas as pd
import os
import openai
from dotenv import set_key, load_dotenv
import requests
from datetime import datetime
from PIL import Image

# Load env
load_dotenv(".env")

from utils import salvar_historico_operacoes, carregar_historico_operacoes, exportar_periodo, reset_history
from indicators import *
from strategies import STRATS, profile_info
from exchanges.binance import BinanceConnector
from ai.salomao import obter_top_ativos_salomao, exibir_racional_ia
from manual.manual import manual_tab
from backtest.backtest import backtest_tab

# Logo
logo_path = "Logo.png"
if os.path.exists(logo_path):
    st.markdown(
        f"""<div style="position: absolute; top: 18px; left: 18px; z-index: 99;">
            <img src="file://{os.path.abspath(logo_path)}" width="56" style="margin-bottom:10px;" />
        </div>""", unsafe_allow_html=True
    )

# THEME SWITCH
THEMES = {
    "Apple Clean": "",  # Seu CSS
    "Apple Dark": "",   # Seu CSS
    "Neon Cyberpunk": "",
    "Bloomberg Pro": "",
    "Crystal Matrix": ""
}
st.sidebar.header("👁️ Tema Visual")
theme = st.sidebar.selectbox("", list(THEMES.keys()), index=0)
if THEMES[theme]: st.markdown(THEMES[theme], unsafe_allow_html=True)

# SIDEBAR CONFIG
st.sidebar.header("⚙️ Configuração Completa")
api_key_binance = st.sidebar.text_input("Binance API Key", type="password", value=os.getenv("API_KEY_BINANCE", ""))
secret_key_binance = st.sidebar.text_input("Binance Secret Key", type="password", value=os.getenv("SECRET_KEY_BINANCE", ""))
openai_api_key = st.sidebar.text_input("OpenAI API Key", type="password", value=os.getenv("OPENAI_API_KEY", ""))
if st.sidebar.button("💾 Salvar Configurações"):
    set_key(".env", "API_KEY_BINANCE", api_key_binance)
    set_key(".env", "SECRET_KEY_BINANCE", secret_key_binance)
    set_key(".env", "OPENAI_API_KEY", openai_api_key)
    openai.api_key = openai_api_key
    st.sidebar.success("Configurações salvas! Recarregue o app.")

openai.api_key = openai_api_key

def consultar_saldo_openai(api_key):
    url = "https://api.openai.com/dashboard/billing/credit_grants"
    headers = {"Authorization": f"Bearer {api_key}"}
    try:
        r = requests.get(url, headers=headers, timeout=15)
        if r.status_code == 200:
            saldo = r.json().get("total_available", 0.0)
            return saldo
        return None
    except Exception: return None

saldo_openai = consultar_saldo_openai(openai_api_key)
if saldo_openai and saldo_openai > 0: st.sidebar.success(f"OpenAI OK: ${saldo_openai:.2f}")
else: st.sidebar.warning("API OpenAI sem saldo ou não conectada.")

try:
    exchange = BinanceConnector(api_key_binance, secret_key_binance) if api_key_binance and secret_key_binance else None
    if exchange: st.sidebar.success("Binance conectada!")
    else: st.sidebar.warning("Preencha API/Secret para Binance.")
except Exception as e:
    exchange = None
    st.sidebar.error(f"Erro Binance: {e}")

ia_ativa = st.sidebar.toggle("🔮 Ativar IA (Olho de Salomão)", value=(saldo_openai and saldo_openai > 0))
exec_ativo = st.sidebar.toggle("⚡ Executor Automático IA", value=False)
st.sidebar.markdown(f"Status Executor: {'🟢 ATIVO' if exec_ativo else '🔴 DESLIGADO'}")

perfil = st.sidebar.selectbox("👤 Perfil de Trading", list(STRATS.keys()))
modo_op = st.sidebar.radio("🚀 Modo de Execução", ["Simulação", "Real"])
trade_base = st.sidebar.selectbox("Base das Operações", ["BTC/USDT", "USDT", "Todos Ativos"])
ativos_analise = [
    "BTC/USDT","ETH/USDT","BNB/USDT","SOL/USDT","XRP/USDT","ADA/USDT","DOGE/USDT","AVAX/USDT",
    "DOT/USDT","LINK/USDT","TRX/USDT","LTC/USDT","MATIC/USDT","UNI/USDT","ATOM/USDT",
    "OP/USDT","SUI/USDT","INJ/USDT","RNDR/USDT","ARB/USDT","FIL/USDT","PEPE/USDT","BLUR/USDT",
    "SEI/USDT","TIA/USDT","SHIB/USDT","JUP/USDT","PYTH/USDT","APT/USDT",
    "FET/USDT","GMT/USDT","GMX/USDT"
]
ativos_escolhidos = st.sidebar.multiselect(
    "Selecione até 10 ativos", ativos_analise, default=ativos_analise[:6], max_selections=10
)
intervalo_refresh = st.sidebar.slider("⏱ Intervalo (s)", 10, 120, 20)
n_top = st.sidebar.slider("N° de moedas IA", 3, 10, 6)

with st.sidebar.expander("📋 Resumo Configuração"):
    st.write(f"Perfil: {perfil}")
    st.write(f"Modo: {modo_op}")
    st.write(f"IA: {'Ativa' if ia_ativa else 'Desativada'}")
    st.write(f"Executor: {'Automático' if exec_ativo else 'Manual'}")
    st.write(f"Trade Base: {trade_base}")
    st.write(f"Intervalo: {intervalo_refresh}s")
    st.write(f"Ativos: {', '.join(ativos_escolhidos)}")
    st.write(f"Tema: {theme}")

tabs = st.tabs([
    "Dashboard", "Olho de Salomão", "Carteira", "Execução", "Motor de Vidro", "Histórico", "3eye Vision", "Manual", "Backtest", "Status"
])

# DASHBOARD
with tabs[0]:
    from dashboard import dashboard_tab
    dashboard_tab(exchange, df_hist=carregar_historico_operacoes(), ativos_escolhidos=ativos_escolhidos, n_top=n_top, ia_ativa=ia_ativa)

# OLHO DE SALOMÃO
with tabs[1]:
    from ai.salomao import olho_salomao_tab
    olho_salomao_tab(exchange, ativos_analise, n_top, ia_ativa, openai_api_key)

# CARTEIRA
with tabs[2]:
    from carteira import carteira_tab
    carteira_tab(exchange, ativos_escolhidos)

# EXECUÇÃO
with tabs[3]:
    from execucao import execucao_tab
    execucao_tab(exchange, ativos_escolhidos, exec_ativo, perfil, modo_op, ia_ativa, openai_api_key)

# MOTOR DE VIDRO
with tabs[4]:
    from motor_vidro import motor_vidro_tab
    motor_vidro_tab()

# HISTÓRICO
with tabs[5]:
    from historico import historico_tab
    historico_tab()

# 3EYE VISION
with tabs[6]:
    from vision import vision_tab
    vision_tab(exchange, ativos_escolhidos, perfil, ia_ativa, openai_api_key, exec_ativo)

# MANUAL
with tabs[7]: manual_tab()
# BACKTEST
with tabs[8]: backtest_tab()
# STATUS
with tabs[9]:
    from status import status_tab
    status_tab(exchange, openai_api_key, saldo_openai, ia_ativa, exec_ativo, perfil, ativos_escolhidos, theme)


