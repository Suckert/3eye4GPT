import streamlit as st
import pandas as pd
import numpy as np
import os
import sys
from datetime import datetime
from dotenv import set_key, load_dotenv

# Permite importar módulos em subpastas
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Importa todos os módulos customizados do projeto
from exchanges.binance import BinanceConnector
from utils.whales import fetch_whale_alerts, fetch_onchain_metric
from utils.logs import log_event, load_logs, filter_logs, replay_operations
from utils.alerts import send_telegram_alert, send_email_alert, send_discord_alert, send_whatsapp_alert
from ai.salomao import obter_top_ativos_salomao, exibir_racional_ia
from ai.sentiment import sentiment_from_news, sentiment_from_reddit, sentiment_from_google_trends
from indicators import compute_rsi, compute_sharpe, compute_sortino, compute_drawdown, compute_volatility
from strategies import STRATS, profile_info

load_dotenv(".env")
st.set_page_config(page_title="3eye IA Ultimate", layout="wide")

# Logo no topo esquerdo
logo_path = "static/images/Logo.png"
if os.path.exists(logo_path):
    st.markdown(
        f"""<div style="position: absolute; top: 18px; left: 18px; z-index: 99;">
            <img src="file://{os.path.abspath(logo_path)}" width="56" style="margin-bottom:10px;" />
        </div>""", unsafe_allow_html=True
    )

# ---- SIDEBAR: Configurações e Chaves ----
THEMES = {
    "Apple Clean": "",
    "Apple Dark": "",
    "Neon Cyberpunk": "",
    "Bloomberg Pro": "",
    "Crystal Matrix": ""
}
st.sidebar.header("👁️ Tema Visual")
theme = st.sidebar.selectbox("", list(THEMES.keys()), index=0)
if THEMES[theme]:
    st.markdown(THEMES[theme], unsafe_allow_html=True)

st.sidebar.header("⚙️ Configuração Completa")
api_key_binance = st.sidebar.text_input("Binance API Key", type="password", value=os.getenv("API_KEY_BINANCE", ""))
secret_key_binance = st.sidebar.text_input("Binance Secret Key", type="password", value=os.getenv("SECRET_KEY_BINANCE", ""))
openai_api_key = st.sidebar.text_input("OpenAI API Key", type="password", value=os.getenv("OPENAI_API_KEY", ""))
whale_alert_api = st.sidebar.text_input("Whale Alert API Key", type="password", value=os.getenv("WHALE_ALERT_API", ""))
telegram_token = st.sidebar.text_input("Telegram Bot Token", type="password", value=os.getenv("TELEGRAM_TOKEN", ""))
telegram_chat = st.sidebar.text_input("Telegram Chat ID", value=os.getenv("TELEGRAM_CHAT", ""))

if st.sidebar.button("💾 Salvar Configurações"):
    set_key(".env", "API_KEY_BINANCE", api_key_binance)
    set_key(".env", "SECRET_KEY_BINANCE", secret_key_binance)
    set_key(".env", "OPENAI_API_KEY", openai_api_key)
    set_key(".env", "WHALE_ALERT_API", whale_alert_api)
    set_key(".env", "TELEGRAM_TOKEN", telegram_token)
    set_key(".env", "TELEGRAM_CHAT", telegram_chat)
    st.sidebar.success("Configurações salvas! Recarregue o app.")

# ---- PARÂMETROS ----
ativos_analise = [
    "BTC/USDT","ETH/USDT","BNB/USDT","SOL/USDT","XRP/USDT","ADA/USDT","DOGE/USDT","AVAX/USDT",
    "DOT/USDT","LINK/USDT","TRX/USDT","LTC/USDT","MATIC/USDT","UNI/USDT","ATOM/USDT",
    "OP/USDT","SUI/USDT","INJ/USDT","RNDR/USDT","ARB/USDT","FIL/USDT","PEPE/USDT","BLUR/USDT",
    "SEI/USDT","TIA/USDT","SHIB/USDT","JUP/USDT","PYTH/USDT","APT/USDT",
    "FET/USDT","GMT/USDT","GMX/USDT"
]
ativos_escolhidos = st.sidebar.multiselect(
    "Selecione até 10 ativos", ativos_analise, default=ativos_analise[:6], max_selections=10
)
perfil = st.sidebar.selectbox("👤 Perfil de Trading", list(STRATS.keys()))
modo_op = st.sidebar.radio("🚀 Modo de Execução", ["Simulação", "Real"])
ia_ativa = st.sidebar.toggle("🔮 Ativar IA (Olho de Salomão)", value=True)
exec_ativo = st.sidebar.toggle("⚡ Executor Automático IA", value=False)
intervalo_refresh = st.sidebar.slider("⏱ Intervalo (s)", 10, 120, 20)
n_top = st.sidebar.slider("N° de moedas IA", 3, 10, 6)

# ---- INICIALIZA EXCHANGE (Binance) ----
exchange = None
if api_key_binance and secret_key_binance:
    try:
        exchange = BinanceConnector(api_key_binance, secret_key_binance)
        st.sidebar.success("Conectado à Binance!")
    except Exception as e:
        st.sidebar.error(f"Erro Binance: {e}")

# ---- DEFINIÇÃO DAS ABAS ----
tabs = st.tabs([
    "Dashboard", "Whales/On-chain", "Logs/Auditoria", "Alertas", "Sentimento Social",
    "Olho de Salomão", "Carteira", "Execução", "Motor de Vidro", "Histórico", "3eye Vision", "Manual", "Backtest", "Status"
])

# ---- DASHBOARD ----
with tabs[0]:
    st.title("👁️ 3eye Ultimate – Dashboard")
    if exchange:
        saldo = exchange.fetch_balance()
        st.subheader("Saldo Binance (Spot):")
        st.dataframe(pd.DataFrame.from_dict(saldo['total'], orient='index', columns=['Total']))
    else:
        st.info("Conecte à Binance para ver o saldo.")
    df_hist = load_logs()
    if not df_hist.empty:
        st.subheader("Performance e Histórico de Trades")
        st.dataframe(df_hist.tail(15))
    else:
        st.info("Nenhuma operação registrada ainda.")
    st.subheader(f"🔮 Top {n_top} Moedas Olho de Salomão")
    scores, racional = obter_top_ativos_salomao(ativos_escolhidos, n_top, ia_ativa, openai_api_key)
    st.dataframe(pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota IA"]))
    exibir_racional_ia(racional)
    st.subheader("🐋 Alertas de Whale (Whale Alert API)")
    if whale_alert_api:
        whales_df = fetch_whale_alerts(whale_alert_api)
        if not whales_df.empty:
            st.dataframe(whales_df.head(10))
        else:
            st.info("Nenhum whale detectado recentemente.")
    else:
        st.warning("Configure sua Whale Alert API Key.")
    st.subheader("🌐 Sentimento Global das Criptos")
    sentiment_news = sentiment_from_news("bitcoin")
    sentiment_reddit = sentiment_from_reddit("CryptoCurrency")
    sentiment_trends = sentiment_from_google_trends("bitcoin")
    st.metric("Notícias", sentiment_news)
    st.metric("Reddit", sentiment_reddit)
    st.metric("Google Trends", sentiment_trends)

# ---- WHALES/ON-CHAIN ----
with tabs[1]:
    st.title("🐋 Whales e Fluxo On-Chain")
    if whale_alert_api:
        whales_df = fetch_whale_alerts(whale_alert_api)
        if not whales_df.empty:
            st.dataframe(whales_df.head(20))
        else:
            st.info("Nenhum whale detectado recentemente.")
    else:
        st.warning("Configure sua Whale Alert API Key.")

# ---- LOGS/AUDITORIA ----
with tabs[2]:
    st.title("📝 Logs Detalhados e Auditoria")
    df_logs = load_logs()
    st.dataframe(df_logs)
    st.subheader("Replay de operações")
    if st.button("▶️ Replay Console"):
        replay_operations(df_logs)

# ---- ALERTAS ----
with tabs[3]:
    st.title("🚨 Alertas Multi-Canal")
    st.write("Envie alertas para Telegram, E-mail, Discord, WhatsApp")
    message = st.text_area("Mensagem de alerta", "Alerta de teste!")
    if st.button("Enviar para Telegram") and telegram_token and telegram_chat:
        send_telegram_alert(telegram_token, telegram_chat, message)
        st.success("Alerta enviado para Telegram!")
    if st.button("Enviar para Discord Webhook"):
        webhook = st.text_input("Discord Webhook URL")
        if webhook:
            send_discord_alert(webhook, message)
            st.success("Alerta enviado para Discord!")
    # Email e WhatsApp semelhantes

# ---- SENTIMENTO SOCIAL ----
with tabs[4]:
    st.title("🗨️ Sentimento Social (Notícias, Reddit, Google Trends)")
    st.metric("Notícias", sentiment_from_news("bitcoin"))
    st.metric("Reddit", sentiment_from_reddit("CryptoCurrency"))
    st.metric("Google Trends", sentiment_from_google_trends("bitcoin"))
    st.info("Adicione Twitter/X e amplie para outros ativos conforme API Key.")

# ---- OLHO DE SALOMÃO ----
with tabs[5]:
    st.title("🔮 Olho de Salomão")
    scores, racional = obter_top_ativos_salomao(ativos_escolhidos, n_top, ia_ativa, openai_api_key)
    st.dataframe(pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota IA"]))
    exibir_racional_ia(racional)

# ---- Continue expandindo as demais abas seguindo este padrão ----
# Carteira, Execução, Motor de Vidro, Histórico, 3eye Vision, Manual, Backtest, Status
# Cada aba chama seus módulos correspondentes, usando logs, alerts, whales, sentiment, etc.
# Não tire nada do que já está, apenas adicione e organize sempre assim

# ---- STATUS ----
with tabs[-1]:
    st.title("🔄 Status do Sistema")
    st.write(f"API Binance: {'OK' if exchange else 'Falha'}")
    st.write(f"API Whale Alert: {'OK' if whale_alert_api else 'Falta Configurar'}")
    st.write(f"Telegram: {'OK' if telegram_token and telegram_chat else 'Falta Configurar'}")
    st.write(f"Sentiment News: {sentiment_from_news('bitcoin')}")
    st.write(f"Sentiment Reddit: {sentiment_from_reddit('CryptoCurrency')}")
    st.write(f"Sentiment Google Trends: {sentiment_from_google_trends('bitcoin')}")
    st.write("Status de outras integrações: implemente conforme necessário.")

# ---- FIM ----


