import ccxt
import pandas as pd

class BinanceConnector:
    def __init__(self, api_key, secret_key):
        self.exchange = ccxt.binance({
            'apiKey': api_key,
            'secret': secret_key,
            'enableRateLimit': True,
            'options': {'defaultType': 'spot'}  # padrão
        })
        self.exchange.load_markets()

    def fetch_ohlcv_df(self, symbol, timeframe='1h', limit=100):
        ohlcv = self.exchange.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
        df = pd.DataFrame(ohlcv, columns=['timestamp', 'open', 'high', 'low', 'close', 'volume'])
        df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
        df.set_index('timestamp', inplace=True)
        return df

    def fetch_recent_orders(self, ativos, tipo='spot', limit=10):
        all_orders = []
        for symbol in ativos:
            try:
                if tipo == 'spot':
                    self.exchange.options['defaultType'] = 'spot'
                    orders = self.exchange.fetch_orders(symbol, limit=limit)
                elif tipo == 'futures':
                    self.exchange.options['defaultType'] = 'future'
                    orders = self.exchange.fetch_orders(symbol, limit=limit)
                elif tipo == 'margin':
                    self.exchange.options['defaultType'] = 'margin'
                    try:
                        orders = self.exchange.fetch_orders(symbol, limit=limit)
                    except Exception:
                        orders = []
                else:
                    orders = []
                for o in orders:
                    all_orders.append({
                        "Ativo": symbol,
                        "Id": o.get("id", ""),
                        "Lado": o.get("side", ""),
                        "Qtd": o.get("amount", ""),
                        "Preço": o.get("price", ""),
                        "Status": o.get("status", ""),
                        "Tipo": o.get("type", ""),
                        "Data": pd.to_datetime(o.get("timestamp", None), unit='ms') if o.get("timestamp", None) else ""
                    })
            except Exception as e:
                continue
        df = pd.DataFrame(all_orders)
        return df if not df.empty else pd.DataFrame({"INFO": ["Nenhuma ordem encontrada"]})

    # Cria ordem mercado (buy/sell)
    def create_market_order(self, symbol, side, quantidade):
        try:
            order = self.exchange.create_market_order(symbol, side, quantidade)
            return order
        except Exception as e:
            return {"error": str(e)}

    # Cria ordem limite
    def create_limit_order(self, symbol, side, quantidade, preco):
        try:
            order = self.exchange.create_limit_order(symbol, side, quantidade, preco)
            return order
        except Exception as e:
            return {"error": str(e)}

    # Cria ordem OCO (One Cancels the Other) - Spot apenas
    def create_oco_order(self, symbol, side, quantidade, preco, stop_price, stop_limit_price):
        try:
            # OCO só disponível na API REST, precisa de chamada direta se não suportado em ccxt
            # Exemplo genérico:
            order = self.exchange.sapi_post_order_oco({
                "symbol": symbol.replace("/", ""),
                "side": side.upper(),
                "quantity": quantidade,
                "price": preco,
                "stopPrice": stop_price,
                "stopLimitPrice": stop_limit_price,
                "stopLimitTimeInForce": "GTC"
            })
            return order
        except Exception as e:
            return {"error": str(e)}

    # Futuros: Ordem mercado ou limite
    def create_futures_order(self, symbol, side, quantidade, tipo="market", preco=None):
        self.exchange.options['defaultType'] = 'future'
        try:
            if tipo == "market":
                order = self.exchange.create_market_order(symbol, side, quantidade)
            elif tipo == "limit" and preco:
                order = self.exchange.create_limit_order(symbol, side, quantidade, preco)
            else:
                raise ValueError("Tipo deve ser 'market' ou 'limit' com preço.")
            return order
        except Exception as e:
            return {"error": str(e)}

    # Margin: Ordem mercado ou limite
    def create_margin_order(self, symbol, side, quantidade, tipo="market", preco=None):
        self.exchange.options['defaultType'] = 'margin'
        try:
            if tipo == "market":
                order = self.exchange.create_market_order(symbol, side, quantidade)
            elif tipo == "limit" and preco:
                order = self.exchange.create_limit_order(symbol, side, quantidade, preco)
            else:
                raise ValueError("Tipo deve ser 'market' ou 'limit' com preço.")
            return order
        except Exception as e:
            return {"error": str(e)}

    # Pega saldo completo
    def fetch_balance(self):
        try:
            return self.exchange.fetch_balance()
        except Exception as e:
            return {"error": str(e)}
