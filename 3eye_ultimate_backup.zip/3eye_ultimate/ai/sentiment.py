import requests
from textblob import TextBlob

def sentiment_from_news(query="bitcoin"):
    url = f'https://news.google.com/rss/search?q={query}'
    import feedparser
    feed = feedparser.parse(url)
    polarities = []
    for entry in feed.entries[:10]:
        try:
            summary = entry.summary
            polarity = TextBlob(summary).sentiment.polarity
            polarities.append(polarity)
        except Exception:
            pass
    return sum(polarities)/len(polarities) if polarities else 0

# Reddit (scraping básico)
def sentiment_from_reddit(subreddit="CryptoCurrency", limit=10):
    url = f"https://www.reddit.com/r/{subreddit}/hot.json?limit={limit}"
    headers = {'User-agent': '3eyeBot'}
    r = requests.get(url, headers=headers)
    posts = r.json().get("data", {}).get("children", [])
    polarities = []
    for post in posts:
        title = post['data']['title']
        polarity = TextBlob(title).sentiment.polarity
        polarities.append(polarity)
    return sum(polarities)/len(polarities) if polarities else 0

# Google Trends (precisa pytrends)
def sentiment_from_google_trends(keyword="bitcoin"):
    from pytrends.request import TrendReq
    pytrend = TrendReq()
    pytrend.build_payload(kw_list=[keyword])
    data = pytrend.interest_over_time()
    if not data.empty:
        return data[keyword].iloc[-1]
    return 0

# Twitter API: use Tweepy (precisa chave dev Twitter)
def sentiment_from_twitter(query="#bitcoin", limit=10, bearer_token=None):
    import tweepy
    client = tweepy.Client(bearer_token=bearer_token)
    tweets = client.search_recent_tweets(query=query, max_results=limit)
    polarities = []
    for tweet in tweets.data:
        polarity = TextBlob(tweet.text).sentiment.polarity
        polarities.append(polarity)
    return sum(polarities)/len(polarities) if polarities else 0
