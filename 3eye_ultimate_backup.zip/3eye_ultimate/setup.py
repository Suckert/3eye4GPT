
from setuptools import setup

setup(
    name='3eye_supreme_ai',
    version='1.0',
    py_modules=['app_3eye_BINANCEFIX_FINAL'],
    install_requires=[
        'streamlit',
        'ccxt'
    ],
    entry_points='''
        [console_scripts]
        3eye=app_3eye_BINANCEFIX_FINAL:main
    ''',
)
