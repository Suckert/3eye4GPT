import streamlit as st

def backtest_tab():
    st.header("⏳ Simulador de Backtest")
    st.info("Em breve: ferramenta completa de teste de estratégias com download em PDF/CSV.")
