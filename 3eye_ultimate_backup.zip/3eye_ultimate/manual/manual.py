def manual_tab():
    import streamlit as st
    import pandas as pd

    st.header("📒 3Eye Manual & Glossário")
    st.success("Manual carregado com sucesso.")

    st.markdown("""
    <h2>Manual de Uso do 3eye IA – Guia Rápido</h2>
    """, unsafe_allow_html=True)

    st.markdown("### Perfis & Modos de Operação")
    st.dataframe(pd.DataFrame([
        ["Conservador", "Opera sinais seguros via RSI baixo (<30)", "Risco mínimo, crescimento lento"],
        ["Balanceado", "Compra/venda por Médias Móveis (MA)", "Risco médio, lucro regular"],
        ["Agressivo", "Compra com fortes tendências", "Risco alto, potencial alto"],
        ["Multiplicação Divina", "Cruza sinais, protege com stop dinâmico", "Alto crescimento com proteção"],
        ["Harmônico", "Busca harmonia das médias móveis", "Reversões rápidas"],
        ["Devoção Fluida", "Foco no equilíbrio de força", "Mercado lateralizado"],
        ["Profético", "Opera reversões e padrões raros", "Grandes viradas"],
        ["3eye IA Power", "Máxima inteligência, une todos modos", "Para auto IA 24h"],
    ], columns=["Perfil", "Estratégia", "Descrição"]).set_index("Perfil"))

    st.markdown("### Indicadores & Legendas")
    st.dataframe(pd.DataFrame([
        ["RSI", "Indica força relativa. Abaixo de 30 = sobrevendido, acima de 70 = sobrecomprado"],
        ["MACD", "Cruzamento de médias. Sinaliza tendência de alta ou baixa"],
        ["ATR", "Volatilidade média. Usado para definir stops"],
        ["OBV", "Volume acumulado para prever movimentos"],
        ["VWAP", "Preço médio ponderado pelo volume"],
        ["Stop-loss", "Protege capital, limitando perdas automaticamente"],
    ], columns=["Indicador", "Explicação"]).set_index("Indicador"))

    st.markdown("### Dicas de Operação")
    st.markdown("""
    - Use Executor IA-Auto sempre que possível para operar 24h de modo protegido.
    - Teste no modo simulação antes de operar real.
    - Rebalanceie sua carteira com frequência, sempre usando as sugestões do sistema.
    - Ative todos os modos de proteção (RSK Shield e ZEN).
    - Confira sempre o Motor de Vidro para ver as decisões da IA ao vivo.
    """)
    st.info("Manual exibido. Consulte sempre que precisar tirar dúvidas sobre funcionalidades ou termos.")
    
    st.markdown("### Glossário de Termos Técnicos")
    st.dataframe(pd.DataFrame([
        ["RSI", "Índice de Força Relativa"],
        ["MACD", "Convergência/Divergência de Médias Móveis"],
        ["ATR", "Amplitude Média Real"],
        ["OBV", "Volume Acumulado"],
        ["VWAP", "Preço Médio Ponderado pelo Volume"],
        ["Backtesting", "Teste de estratégia com dados históricos"],
        ["Stop-loss", "Limita sua perda"],
        ["Take-profit", "Garante seu lucro automaticamente"],
    ], columns=["Termo", "Significado"]).set_index("Termo"))
