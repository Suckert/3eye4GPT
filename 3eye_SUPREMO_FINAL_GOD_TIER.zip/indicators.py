import numpy as np
import pandas as pd

def compute_rsi(series, period=14):
    delta = series.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(window=period).mean()
    avg_loss = loss.rolling(window=period).mean()
    rs = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    return rsi

def compute_macd(series, fast=12, slow=26, signal=9):
    ema_fast = series.ewm(span=fast, adjust=False).mean()
    ema_slow = series.ewm(span=slow, adjust=False).mean()
    macd = ema_fast - ema_slow
    macd_signal = macd.ewm(span=signal, adjust=False).mean()
    macd_hist = macd - macd_signal
    return macd, macd_signal, macd_hist

def compute_atr(df, period=14):
    high_low = df['high'] - df['low']
    high_close = np.abs(df['high'] - df['close'].shift())
    low_close = np.abs(df['low'] - df['close'].shift())
    ranges = pd.concat([high_low, high_close, low_close], axis=1)
    true_range = ranges.max(axis=1)
    atr = true_range.rolling(window=period).mean()
    return atr

def indicator_score(df):
    score = 0
    votes = 0
    rsi = compute_rsi(df['close']).iloc[-1]
    if rsi < 30:
        score += 2; votes += 2
    elif rsi > 70:
        score -= 2; votes += 2
    macd, signal, _ = compute_macd(df['close'])
    if macd.iloc[-1] > signal.iloc[-1]:
        score += 2; votes += 2
    else:
        score -= 2; votes += 2
    prob = 50 + (score * (100/votes)/2 if votes else 0)
    prob = min(100, max(0, prob))
    tendencia = "Alta" if prob > 60 else "Baixa" if prob < 40 else "Indefinida"
    return {
        "score": score,
        "probabilidade_alta": prob,
        "tendencia": tendencia,
        "rsi": rsi,
        "macd": macd.iloc[-1],
        "signal": signal.iloc[-1],
    }
