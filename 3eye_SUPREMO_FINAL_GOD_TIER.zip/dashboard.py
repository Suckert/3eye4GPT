def dashboard_tab(exchange, df_hist, ativos_escolhidos, n_top, ia_ativa):
    import streamlit as st
    import pandas as pd
    from ai.salomao import obter_top_ativos_salomao, exibir_racional_ia

    st.title("👁️ 3eye Ultimate – Painel Geral (Landing Page)")

    # --- Performance Real ---
    capital_inicial = 10000
    if not df_hist.empty:
        df_hist = df_hist.sort_values("DataHora")
        df_hist["Valor"] = df_hist["Preço"] * df_hist.get("Quantidade", 1)
        df_hist["Capital"] = capital_inicial + df_hist["Valor"].cumsum()
        lucro_total = df_hist["Valor"].sum()
        n_trades = len(df_hist)
        acertos = len(df_hist[df_hist["Ação"].str.lower() == "buy"])
        st.subheader("📈 Performance e Estatísticas")
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Capital Atual", f"${df_hist['Capital'].iloc[-1]:,.2f}")
        col2.metric("Lucro Total", f"${lucro_total:,.2f}")
        col3.metric("Nº Trades", f"{n_trades}")
        col4.metric("Acertos", f"{acertos}")
        st.line_chart(df_hist[["Capital"]])
    else:
        st.info("Nenhuma operação registrada ainda.")

    # --- Carteira Resumida ---
    st.markdown("---")
    st.subheader("💼 Carteira Atual (Espelho Resumido)")
    if exchange:
        saldo_sim = {
            ativo: {"saldo": round(100 + (i*5), 2), "preco_atual": 20+2*i, "lucro": round((i-3)*13,2)}
            for i, ativo in enumerate(ativos_escolhidos)
        }
        df_cart = pd.DataFrame([
            [a, v["saldo"], v["preco_atual"], v["saldo"]*v["preco_atual"], v["lucro"]]
            for i, (a, v) in enumerate(saldo_sim.items())
        ], columns=["Ativo", "Saldo", "Preço Atual", "Valor Total", "Lucro"])
        df_cart["% Alocação"] = df_cart["Valor Total"]/df_cart["Valor Total"].sum()*100
        st.dataframe(df_cart)
        st.metric("Lucro Total", f"${df_cart['Lucro'].sum():,.2f}")
        st.bar_chart(df_cart.set_index("Ativo")["Valor Total"])
    else:
        st.warning("Conecte sua conta Binance para ver a carteira real.")

    # --- Top 6 Olho de Salomão ---
    st.markdown("---")
    st.subheader("🔮 Top 6 Moedas Recomendadas Hoje (Olho de Salomão)")
    try:
        scores, racional = obter_top_ativos_salomao(ativos_escolhidos, n_top, ia_ativa)
        df_ia = pd.DataFrame(list(scores.items()), columns=["Ativo", "Nota IA"]).sort_values("Nota IA", ascending=False)
        top6 = df_ia.head(n_top)["Ativo"].tolist()
        st.info(f"Top{n_top}: {', '.join(top6)}")
        st.dataframe(df_ia)
        exibir_racional_ia(racional)
    except Exception as e:
        st.error(f"Erro na IA: {e}")

    # --- Histórico Recentes ---
    st.markdown("---")
    st.subheader("📜 Últimas Operações")
    if not df_hist.empty:
        st.dataframe(df_hist.tail(10))
    else:
        st.info("Nenhuma operação registrada ainda.")

    # --- Status e Segurança ---
    st.markdown("---")
    st.subheader("🛡️ Status & Segurança do Sistema")
    now = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
    def status_icon(ok): return "✅" if ok else "❌"
    status_data = [
        ("Conexão Binance", status_icon(exchange is not None), 
         "Conectado" if exchange else "Verifique API/Secret e conexão Internet"),
        ("IA Ativa", status_icon(ia_ativa), "IA funcionando" if ia_ativa else "IA desligada ou sem saldo"),
        ("Horário Atual", "🕒", now),
        ("Ativos escolhidos", status_icon(len(ativos_escolhidos) > 0), f"{', '.join(ativos_escolhidos)}"),
    ]
    st.table(pd.DataFrame(status_data, columns=["Recurso", "Status", "Motivo/Descrição"]))

    st.markdown("---")
    st.subheader("💡 Dicas & Alertas Inteligentes")
    st.info("Proteja sempre seu capital! Use stop-loss, take-profit, e revise o Motor de Vidro para evitar perdas desnecessárias.")
